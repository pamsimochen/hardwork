/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== App.c ========
 *
 */

/* host header files */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* package header files */
#include <ti/syslink/Std.h>     /* must be first */

#include <ti/ipc/MessageQ.h>
#include <ti/ipc/SharedRegion.h>

#include <ti/syslink/ProcMgr.h>
#include <ti/syslink/utils/IHeap.h>
#include <ti/syslink/utils/Memory.h>

/* local header files */
#include "App.h"
#include "../shared/ServerProtocol.h"

/* module structure */
typedef struct {
    ProcMgr_Handle      proc;           /* handle to slave proc mngr */
    IHeap_Handle        heap;           /* SR_0 heap handle     */
    MessageQ_Handle     hostQue;        /* created locally      */
    MessageQ_QueueId    slaveQue;       /* opened remotely      */
    Server_Msg *        msg;            /* static message buffer */
    SizeT               msgSize;
    UInt32              slaveBufBase;   /* slave's data buffer */
    Int                 slaveBufCount;  /* size of buffer in elements */
} App_Module;


/* private data */
static App_Module       Module;
static Int              Mod_curInit = 0;
static Int32 *          localDataBuf = NULL;


/*
 *  ======== App_destroy ========
 */
Int App_destroy(Void)
{
    Int status = 0;

    printf("--> App_destroy:\n");

    /* reference count the module usage */
    if (Mod_curInit-- != 1) {
        goto leave;  /* object still being used */
    }

    /* send the stop message */
    Module.msg->cmd = Server_Cmd_STOP;
    MessageQ_put(Module.slaveQue, (MessageQ_Msg)Module.msg);

    /* wait for return message */
    status = MessageQ_get(Module.hostQue, (MessageQ_Msg *)&Module.msg,
        MessageQ_FOREVER);

    if (status < 0) {
        printf("Error: %s, line %d: App_destroy: message receive error=%d\n",
                __FILE__, __LINE__, status);
        goto leave;
    }

    /* free local data buffer */
    free(localDataBuf);
    localDataBuf = NULL;

    /* free the static message buffer */
    Memory_free(Module.heap, Module.msg, Module.msgSize);

    /* close remote message queue */
    status = MessageQ_close(&Module.slaveQue);

    if (status < 0) {
        printf("Error: %s, line %d: App_destroy: queue close error=%d\n",
                __FILE__, __LINE__, status);
        goto leave;
    }

    /* delete the local message queue */
    status = MessageQ_delete(&Module.hostQue);

    if (status < 0) {
        printf("Error: %s, line %d: App_destroy: queue delete error=%d\n",
                __FILE__, __LINE__, status);
        goto leave;
    }

    /* close the slave's processor manager handle */
    status = ProcMgr_close(&Module.proc);

    if (status < 0) {
        printf("Error: %s, line %d: App_destroy: ProcMgr_close error=%d\n",
                __FILE__, __LINE__, status);
        goto leave;
    }
    else {
        status = 0;
    }

leave:
    printf("<-- App_destroy: status=%d\n", status);
    return(status);
}

/*
 *  ======== App_run ========
 */
Int App_run(Void)
{
    Int         status = 0;
    Int         i, j, shift;
    UInt32      size;

    printf("--> App_run:\n");

    /* main process loop */
    for (i = 1; i <= 6; i++) {

        /* compute shift factor */
        shift = i % 3; /* 1, 2, 0, 1, ... */

        printf("App_run: process buffer %d, shift=%d\n", i, shift);

        /* fill local data buffer, this might be acquired from peripheral */
        for (j = 0; j < Module.slaveBufCount; j++) {
            localDataBuf[j] = 128;
        }

        printf("App_run: localDataBuf[0-3]: %3d %3d %3d %3d\n",
                localDataBuf[0], localDataBuf[1], localDataBuf[2],
                localDataBuf[3]);
        printf("\n");

        /* write local data buffer to slave data buffer */
        size = Module.slaveBufCount * sizeof(Int32);

        status = ProcMgr_write(Module.proc, Module.slaveBufBase, &size,
                localDataBuf);

        if (status < 0) {
            printf("Error: %s, line %d: App_run: ProcMgr_write error=%d\n",
                    __FILE__, __LINE__, status);
            goto leave;
        }
        else {
            status = 0;
        }

        /* send process message to slave */
        Module.msg->cmd = Server_Cmd_PROCESS;
        Module.msg->shift = shift;

        MessageQ_put(Module.slaveQue, (MessageQ_Msg)Module.msg);

        /* wait for return message */
        status = MessageQ_get(Module.hostQue, (MessageQ_Msg *)&Module.msg,
            MessageQ_FOREVER);

        if (status < 0) {
            printf("Error: %s, line %d: App_run: message receive error=%d\n",
                    __FILE__, __LINE__, status);
            goto leave;
        }

        printf("App_run: received buffer %d\n", i);

        /* readl slave data buffer back into local data buffer */
        size = Module.slaveBufCount * sizeof(Int32);

        status = ProcMgr_read(Module.proc, Module.slaveBufBase, &size,
                localDataBuf);

        if (status < 0) {
            printf("Error: %s, line %d: App_run: ProcMgr_read error=%d\n",
                    __FILE__, __LINE__, status);
            goto leave;
        }
        else {
            status = 0;
        }

        printf("App_run: localDataBuf[0-3]: %3d %3d %3d %3d\n",
                localDataBuf[0], localDataBuf[1], localDataBuf[2],
                localDataBuf[3]);
        printf("\n");
    }

leave:
    printf("<-- App_run: %d\n", status);
    return(status);
}

/*
 *  ======== App_setup ========
 */
Int App_setup(UInt16 remoteProcId)
{
    Int                 status = 0;
    MessageQ_Params     msgqParams;
    Char                queNameBuf[32];

    printf("--> App_setup:\n");

    /* reference count the module usage */
    if (Mod_curInit++ != 0) {
        goto leave;  /* already initialized */
    }

    /* initialize module state */
    Module.proc = NULL;
    Module.heap = NULL;
    Module.hostQue = NULL;
    Module.slaveQue = MessageQ_INVALIDMESSAGEQ;
    Module.msg = NULL;
    Module.msgSize = sizeof(Server_Msg);
    Module.slaveBufBase = 0;
    Module.slaveBufCount = 0;

    /* open the slave's processor manager handle */
    status = ProcMgr_open(&Module.proc, remoteProcId);

    if (status < 0) {
        printf("Error: %s, line %d: App_setup: ProcMgr_open error=%d\n",
                __FILE__, __LINE__, status);
        goto leave;
    }
    else {
        status = 0;
    }

    /* get the SR_0 heap handle */
    Module.heap = (IHeap_Handle)SharedRegion_getHeap(0);

    /* create local message queue (inbound messages) */
    MessageQ_Params_init(&msgqParams);

    Module.hostQue = MessageQ_create(App_MsgQueName, &msgqParams);

    if (Module.hostQue == NULL) {
        printf("Error: %s, line %d: App_setup: message queue create failed\n",
                __FILE__, __LINE__);
        status = -1;
        goto leave;
    }

    /* compute the remote message queue name */
    sprintf(queNameBuf, Server_MsgQueNameFmt, MultiProc_getName(remoteProcId));

    /* open the remote message queue, loop until queue is available */
    do {
        status = MessageQ_open(queNameBuf, &Module.slaveQue);
        if (status == MessageQ_E_NOTFOUND) {
            sleep(1);
        }
    } while (status == MessageQ_E_NOTFOUND);

    if (status < 0) {
        printf("Error: %s, line %d: App_setup: could not open slave message"
                "queue, error=%d\n", __FILE__, __LINE__, status);
        goto leave;
    }

    /* allocate a static message buffer from SR_0 heap */
    Module.msg = (Server_Msg *)Memory_alloc(Module.heap, Module.msgSize,
            0, NULL);

    if (Module.msg == NULL) {
        printf("Error: %s, line %d: App_setup: could not allocate message\n",
                __FILE__, __LINE__);
        status = -1;
        goto leave;
    }

    /* initialize message header, only needs to be done once */
    MessageQ_staticMsgInit((MessageQ_Msg)Module.msg, Module.msgSize);
    MessageQ_setReplyQueue(Module.hostQue, (MessageQ_Msg)Module.msg);

    /* send start message */
    Module.msg->cmd = Server_Cmd_START;
    MessageQ_put(Module.slaveQue, (MessageQ_Msg)Module.msg);

    /* wait for return message */
    status = MessageQ_get(Module.hostQue, (MessageQ_Msg *)&Module.msg,
            MessageQ_FOREVER);

    if (status < 0) {
        printf("Error: %s, line %d: App_setup: message receive error=%d\n",
                __FILE__, __LINE__, status);
        goto leave;
    }

    /* save the slave's data buffer address and size */
    Module.slaveBufBase = Module.msg->slaveBufBase;
    Module.slaveBufCount = Module.msg->slaveBufCount;
    printf("App_setup: slaveBufBase=%p (slave VA), count=%d\n",
            (void *)Module.msg->slaveBufBase, Module.msg->slaveBufCount);

    /* allocate local data buffer from rts heap */
    localDataBuf = (Int32 *)malloc(Module.slaveBufCount * sizeof(Int32));

    if (localDataBuf == NULL) {
        printf("Error: %s, line %d: App_setup: could not allocate local data"
                "buffer\n", __FILE__, __LINE__);
        status = -1;
        goto leave;
    }

leave:
    printf("<-- App_setup: status=%d\n", status);
    return(status);
}
