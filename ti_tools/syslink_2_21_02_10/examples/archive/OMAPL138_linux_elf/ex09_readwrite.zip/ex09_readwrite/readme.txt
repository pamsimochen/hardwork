#
#  ======== readme.txt ========
#

ex09_readwrite - ProcMgr read/write example

[TBD]


To build and run the example
====================================
Prompt: [host] - run these commands on your build host (Linux, Windows)
Prompt: [target] - run these commands on your embedded system

1. Edit products.mak and specify the product install paths.

    [host] cd ex09_readwrite
    [host] edit products.mak

2. Run make to build the example.

    [host] cd ex09_readwrite
    [host] make

3. Build the install goal to copy files to your target file system.

    [host] cd ex09_readwrite
    [host] make install EXEC_DIR=/target_file_system/...

4. Use the run.sh script to run the example.

    [target] cd ex09_readwrite/debug
    [target] run.sh
