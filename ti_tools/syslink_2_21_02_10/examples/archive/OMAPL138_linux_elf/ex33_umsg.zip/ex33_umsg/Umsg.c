/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== Umsg.c ========
 *
 */

#if defined(BUILD_XDC)

/* this define must precede inclusion of any xdc header file */
#define Registry_CURDESC Umsg__Desc

#include <xdc/std.h>
#include <xdc/runtime/Diags.h>
#include <xdc/runtime/Log.h>
#include <xdc/runtime/Memory.h>
#include <xdc/runtime/Registry.h>

#elif defined(SYSLINK_BUILDOS_LINUX)
#include <stdio.h>
#include <unistd.h>

#include <ti/syslink/Std.h>
#include <ti/syslink/utils/Memory.h>

#else
#error Undefined build type
#endif

#include <ti/ipc/HeapMemMP.h>
#include <ti/ipc/MultiProc.h>
#include <ti/ipc/NameServer.h>
#include <ti/ipc/SharedRegion.h>

/* this module's header files */
#include "Umsg.h"
#include "UmsgInternal.h"

static Int Umsg_Instance_init(Umsg_Object *obj, String name, Bool writer,
        UInt16 remoteProcId, const Umsg_Params *params);
static Void Umsg_Instance_finalize(Umsg_Object *obj, Int state);

/* private data */
#if defined(BUILD_XDC)
extern Registry_Desc Registry_CURDESC;
#endif
Umsg_Module     Umsg_mod;


/*
 *  ======== Umsg_alloc ========
 */
Ptr Umsg_alloc(Umsg_Handle handle)
{
    Umsg_Object *       obj = (Umsg_Object *)handle;
    Queue *             freeQue = obj->freeQue;
    SharedRegion_SRPtr  srPtr;
    Ptr                 msg = NULL;

    /* check if message pool is empty */
    if (freeQue->head == freeQue->tail) {
        Umsg_error0("Umsg_alloc: message pool is empty");
        goto leave;
    }

    /* allocate message from the pool free list */
    srPtr = (SharedRegion_SRPtr)(obj->freeAry[freeQue->head]);
    freeQue->head = (freeQue->head + 1) % freeQue->count;
    msg = SharedRegion_getPtr(srPtr);

leave:
    return(msg);
}

/*
 *  ======== Umsg_close ========
 */
Void Umsg_close(Umsg_Handle *handlePtr)
{
    Umsg_Object *obj;

    Log_print0(Diags_ENTRY | Diags_INFO, "--> Umsg_close:");

    /* check for null pointer */
    if ((handlePtr == NULL) || (*handlePtr == NULL)) {
        Umsg_error0("Umsg_close: invalid handle");
        goto leave;
    }

    /* set local context */
    obj = (Umsg_Object *)(*handlePtr);

    /* cancel the wait index reservation */
    Umsg_Device_cancelWaitIndex(obj->block->waitIndex);

    /* free the instance object */
    Memory_free(NULL, obj, sizeof(Umsg_Object));
    *handlePtr = NULL;

leave:
    Log_print0(Diags_EXIT | Diags_INFO, "<-- Umsg_close:");
    return;
}

/*
 *  ======== Umsg_create ========
 */
Umsg_Handle Umsg_create(String name, Bool writer, UInt16 remoteProcId,
        Umsg_Params *params)
{
    Int             status = Umsg_S_SUCCESS;
    Umsg_Object *   obj;
    SizeT           size = sizeof(Umsg_Object);

    Log_print0(Diags_ENTRY | Diags_INFO, "--> Umsg_create:");

    /* allocate the instance object */
    obj = Memory_calloc(NULL, size, 0, NULL);

    if (obj == NULL) {
        Umsg_error1("Umsg_create: out of memory, size=%d", size);
        status = Umsg_E_MEMORY;
        goto leave;
    }

    /* object-specific initialization */
    status = Umsg_Instance_init(obj, name, writer, remoteProcId, params);

    if (status != 0) {  /* might be positive value */
        Umsg_error1("Umsg_create: instance init error=%d", status);
        Umsg_Instance_finalize(obj, status);
        Memory_free(NULL, obj, size);
        obj = NULL;
        goto leave;
    }

leave:
    Log_print0(Diags_EXIT | Diags_INFO, "<-- Umsg_create:");
    return((Umsg_Handle)obj);
}

/*
 *  ======== Umsg_delete ========
 */
Void Umsg_delete(Umsg_Handle *handlePtr)
{
    Int             status = Umsg_S_SUCCESS;
    Umsg_Object *   obj;

    Log_print0(Diags_ENTRY | Diags_INFO, "--> Umsg_delete:");

    /* check for null pointer */
    if ((handlePtr == NULL) || (*handlePtr == NULL)) {
        Umsg_error0("Umsg_delete: invalid handle");
        status = Umsg_E_ARG;
        goto leave;
    }

    /* module specific finalization */
    obj = (Umsg_Object *)(*handlePtr);
    Umsg_Instance_finalize(obj, status);

    /* delete the instance object */
    Memory_free(NULL, obj, sizeof(Umsg_Object));
    *handlePtr = NULL;

leave:
    Log_print0(Diags_EXIT | Diags_INFO, "<-- Umsg_delete:");
    return;
}

/*
 *  ======== Umsg_free ========
 */
Void Umsg_free(Umsg_Handle handle, Ptr msg)
{
    Umsg_Object *       obj;
    Queue *             freeQue;
    SharedRegion_SRPtr  srPtr;

    /* setup local context */
    obj = (Umsg_Object *)handle;
    freeQue = obj->freeQue;

    /* return message to free list */
    srPtr = SharedRegion_getSRPtr(msg, obj->regionId);
    obj->freeAry[freeQue->tail] = (UInt32)srPtr;
    freeQue->tail = (freeQue->tail + 1) % freeQue->count;
}

/*
 *  ======== Umsg_get ========
 */
Ptr Umsg_get(Umsg_Handle handle)
{
    Umsg_Object *       obj;
    Queue *             inboxQue;
    SharedRegion_SRPtr  srPtr;
    Ptr                 msg;

    /* setup local context */
    obj = (Umsg_Object *)handle;
    inboxQue = obj->inboxQue;

    /* if inbox is empty, wait for next message */
    if (inboxQue->head == inboxQue->tail) {
        Umsg_Device_wait(obj->msgCount, obj->block->waitIndex);
    }

    /* remove message from inbox */
    srPtr = obj->inboxAry[inboxQue->head];
    inboxQue->head = (inboxQue->head + 1) % inboxQue->count;
    obj->msgCount++;

    /* return message to caller */
    msg = SharedRegion_getPtr(srPtr);

    return(msg);
}

/*
 *  ======== Umsg_open ========
 */
Int Umsg_open(String name, Umsg_Handle *hPtr)
{
    Int                 status = Umsg_S_SUCCESS;
    Umsg_Object *       obj = NULL;
    SharedRegion_SRPtr  srPtr;
    UInt16              readerProc;
    UInt16              writerProc;

    Log_print0(Diags_ENTRY | Diags_INFO, "--> Umsg_open:");

    /* get the umsg block address from name server */
    status = NameServer_getUInt32(Umsg_mod.nameServer, name, &srPtr, NULL);

    if (status < 0) {
        Umsg_error1("Umsg_open: NameServer_getUInt32() error=%d", status);
        status = Umsg_E_ARG;
        goto leave;
    }
    else {
        status = Umsg_S_SUCCESS;
    }

    /* allocate the instance object */
    obj = Memory_calloc(NULL, sizeof(Umsg_Object), 0, NULL);

    if (obj == NULL) {
        Umsg_error1("Umsg_open: out of memory, size=%d", sizeof(Umsg_Object));
        status = Umsg_E_MEMORY;
        goto leave;
    }

    /* umsg block (local address) */
    obj->block = SharedRegion_getPtr(srPtr);

    /* ensure the correct processor is opening this umsg block */
    if (obj->block->openProcId != MultiProc_self()) {
        Umsg_error2("Umsg_open: incorrect processor, open=%d, self=%d",
                obj->block->openProcId, MultiProc_self());
        status = Umsg_E_ARG;
        goto leave;
    }

    obj->size = 0; /* open flag */
    obj->msgCount = 0;

    /* setup the role properties */
    if (obj->block->writer) {
        /* create umsg object as reader */
        obj->dstIsrState = NULL;
    }
    else {
        /* create umsg object as writer */
        readerProc = obj->block->createProcId;
        writerProc = obj->block->openProcId;
        obj->dstIsrState = &(Umsg_mod.sys->isrSt[readerProc][writerProc]);
    }

    /* inbox */
    obj->inboxQue = (Queue *)(obj->block);
    srPtr = (SharedRegion_SRPtr)(obj->inboxQue->array);
    obj->inboxAry = SharedRegion_getPtr(srPtr);

    /* free list */
    obj->freeQue = (Queue *)((Char *)(obj->block) + sizeof(Queue));
    srPtr = (SharedRegion_SRPtr)(obj->freeQue->array);
    obj->freeAry = SharedRegion_getPtr(srPtr);

    /* reserve wait index, device specific */
    Umsg_Device_reserveWaitIndex(obj->block->waitIndex);

    /* the following instance properties are not used */
    obj->heap = NULL;
    obj->key = NULL;

    /* return the umsg instance handle */
    *hPtr = (Umsg_Handle)obj;

leave:
    /* error handling */
    if (status < 0) {
        if (obj != NULL) {
            Memory_free(NULL, obj, sizeof(Umsg_Object));
        }
        *hPtr = NULL;
    }
    Log_print0(Diags_EXIT | Diags_INFO, "<-- Umsg_open:");
    return(status);
}

/*
 *  ======== Umsg_put ========
 *  Deliver the given message and signal recipient
 */
Int Umsg_put(Umsg_Handle handle, Ptr msg)
{
    Int                 status = Umsg_S_SUCCESS;
    Umsg_Object *       obj;
    Queue *             inboxQue;
    UInt                next;
    SharedRegion_SRPtr  srPtr;

    /* TODO assert(obj->isrQue != NULL) */

    /*  The order of operations is important.
     *  1. enqueue message in reader's inbox
     *  2. enqueue wait index in isr state
     *  3. increment count in isr state
     *  4. raise interrupt
     */

    /* setup local context */
    obj = (Umsg_Object *)handle;
    inboxQue = obj->inboxQue;

    /* TODO enter gate */

    /* compute next slot in the inbox queue */
    next = (inboxQue->tail + 1) % inboxQue->count;

    /* check if inbox is full */
    if (next == inboxQue->head) {
        Umsg_error0("Umsg_put: inbox is full");
        status = Umsg_E_FULL;
        goto leave;
    }

    /* put message in inbox */
    else {
        srPtr = SharedRegion_getSRPtr(msg, obj->regionId);
        obj->inboxAry[inboxQue->tail] = (UInt32)srPtr;
        inboxQue->tail = next;
    }

    /* enqueue the wait index */
    next = (obj->dstIsrState->isrQue.tail + 1) % obj->dstIsrState->isrQue.count;

    if (next == obj->dstIsrState->isrQue.head) {
        Umsg_error0("Umsg_put: isr queue is full");
        status = Umsg_E_FULL;
        goto leave;
    }
    else {
        obj->dstIsrState->isrAry[obj->dstIsrState->isrQue.tail] =
                obj->block->waitIndex;
        obj->dstIsrState->isrQue.tail = next;
    }

    /* increment interrupt count, must be done after enqueue wait index */
    obj->dstIsrState->count++;

    /* TODO leave gate */

    /* raise interrupt to reader */
    Umsg_Device_raiseInterrupt();

leave:
    return(status);
}

/*
 *  ======== Umsg_Instance_finalize ========
 */
Void Umsg_Instance_finalize(Umsg_Object *obj, Int state)
{
    Int         status = Umsg_S_SUCCESS;
    UInt16      readerProc;
    Int         wi, mai, bit;
    UInt32      mask;
    IArg        key;

    /* release the wait index back to the reader's pool */
    key = Umsg_enterGate();

    wi = obj->block->waitIndex;
    readerProc = obj->block->writer ? obj->block->openProcId : MultiProc_self();
    mai = wi / 32;              /* mask array index */
    bit = wi - (mai * 32);      /* bit offset */
    mask = 0x1 << bit;
    Umsg_mod.sys->wiMskAry[readerProc][mai] &= ~(mask);

    Umsg_leaveGate(key);

    /* remove the name server entry */
    status = NameServer_removeEntry(Umsg_mod.nameServer, obj->key);

    if (status < 0) {
        Umsg_error1("Umsg_Instance_finalize: NameServer_removeEntry() error=%d",
                status);
        status = Umsg_E_FAIL;
        /* must continue, cannot return error status */
    }

    /* delete the umsg block */
    HeapMemMP_free(obj->heap, obj->block, obj->size);
}

/*
 *  ======== Umsg_Instance_init ========
 */
Int Umsg_Instance_init(Umsg_Object *obj, String name, Bool writer,
        UInt16 remoteProcId, const Umsg_Params *params)
{
    Int                 status = Umsg_S_SUCCESS;
    IArg                key;
    UInt16              readerProc;
    UInt16              writerProc;
    SizeT               offset;
    UInt32 *            addr;
    Int                 i, wi, mai, bit;
    UInt32              mask;
    SharedRegion_SRPtr  srPtr;

    /* validate params */
    if (params->poolCount < 4) {
        status = Umsg_E_PARAM;
        goto leave;
    }
    if ((params->msgSize % sizeof(UInt32)) != 0) {
        status = Umsg_E_PARAM;
        goto leave;
    }

    /* compute total size of instance */
    obj->size = sizeof(Umsg_Block) +                            /* block    */
            ((params->inboxCount + 1) * sizeof(UInt32)) +       /* inbox    */
            ((params->poolCount + 1) * sizeof(UInt32)) +        /* free     */
            (params->poolCount * params->msgSize);              /* pool     */

    /* allocate the umsg block */
    obj->regionId = params->regionId;
    obj->heap = SharedRegion_getHeap(obj->regionId);

    if (obj->heap == NULL) {
        Umsg_error1("Umsg_Instance_init: shared region heap is null, id=%d",
                obj->regionId);
        status = Umsg_E_CONFIG;
        goto leave;
    }

    obj->block = HeapMemMP_alloc(obj->heap, obj->size, 0);

    if (obj->block == NULL) {
        Umsg_error1("Umsg_Instance_init: out of memory, size=%d", obj->size);
        status = Umsg_E_MEMORY;
        goto leave;
    }

    /* setup the role properties */
    if (writer) {
        /* create umsg object as writer */
        readerProc = remoteProcId;
        writerProc = MultiProc_self();
        obj->dstIsrState = &(Umsg_mod.sys->isrSt[readerProc][writerProc]);
    }
    else {
        /* create umsg object as reader */
        readerProc = MultiProc_self();
        obj->dstIsrState = NULL;
    }
    obj->block->writer = writer;
    obj->block->createProcId = MultiProc_self();
    obj->block->openProcId = remoteProcId;

    /* inbox */
    obj->inboxQue = (Queue *)(obj->block);
    obj->inboxQue->head = 0;
    obj->inboxQue->tail = 0;
    obj->inboxQue->count = params->inboxCount + 1;

    offset = sizeof(Umsg_Block);
    obj->inboxAry = (UInt32 *)((Char *)(obj->block) + offset);
    srPtr = SharedRegion_getSRPtr(obj->inboxAry, obj->regionId);
    obj->inboxQue->array = (UInt32 *)srPtr;

    obj->msgCount = 0;

    /* free list */
    obj->freeQue = (Queue *)((Char *)(obj->block) + sizeof(Queue));
    obj->freeQue->head = 0;
    obj->freeQue->count = params->poolCount + 1;
    obj->freeQue->tail = obj->freeQue->count - 1;

    offset = sizeof(Umsg_Block) + (obj->inboxQue->count * sizeof(UInt32));
    obj->freeAry = (UInt32 *)((Char *)(obj->block) + offset);
    srPtr = SharedRegion_getSRPtr(obj->freeAry, obj->regionId);
    obj->freeQue->array = (UInt32 *)srPtr;

    /* populate the free list */
    offset = sizeof(Umsg_Block) +                           /* block     */
            ((obj->inboxQue->count) * sizeof(UInt32)) +     /* inbox ary */
            ((obj->freeQue->count) * sizeof(UInt32));       /* free ary  */
    addr = (UInt32 *)((Char *)(obj->block) + offset);

    for (i = 0; i < (obj->freeQue->count - 1); i++) {
        srPtr = SharedRegion_getSRPtr(addr, obj->regionId);
        obj->freeAry[i] = (UInt32)srPtr;
        addr = (UInt32 *)((Char *)addr + params->msgSize);
    }

    /* add object address (as SRPtr) to name server */
    srPtr = SharedRegion_getSRPtr(obj->block, obj->regionId);
    obj->key = NameServer_addUInt32(Umsg_mod.nameServer, name, srPtr);

    if (obj->key == NULL) {
        Umsg_error0("Umsg_Instance_init: NameServer_addUInt32() failed");
        status = Umsg_E_FAIL;
        goto leave;
    }

    /* acquire a wait index, take from reader's pool */
    key = Umsg_enterGate();

    for (wi = 0; wi < WI_MAX; wi++) {
        mai = wi / 32;          /* mask array index */
        bit = wi - (mai * 32);  /* bit offset */
        mask = 0x1 << bit;

        /* if wi is available, then take it */
        if ((Umsg_mod.sys->wiMskAry[readerProc][mai] & mask) == 0) {
            Umsg_mod.sys->wiMskAry[readerProc][mai] |= mask;
            obj->block->waitIndex = wi;
            break;
        }
    }

    if (wi == WI_MAX) {
        status = Umsg_E_FAIL;
        /* continue, must leave gate */
    }

    Umsg_leaveGate(key);

    if (status < 0) {
        Umsg_error0("Umsg_Instance_init: wait index pool is empty");
        goto leave;
    }

leave:
    /* error handling */
    if (status < 0) {
        if (obj->block != NULL) {
            HeapMemMP_free(obj->heap, obj->block, obj->size);
        }
        obj = NULL;

        /* TODO name server resources */
        /* TODO test failure, had HeapMemMP assert */
    }
    return(status);
}

/*
 *  ======== Umsg_Params_init ========
 */
Void Umsg_Params_init(Umsg_Params *params)
{
    params->msgSize = 32;
    params->poolCount = 8;
    params->inboxCount = 7;
    params->regionId = 0;
}
