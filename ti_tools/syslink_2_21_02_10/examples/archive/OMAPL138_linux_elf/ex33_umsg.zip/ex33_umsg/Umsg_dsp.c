/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== Umsg_dsp.c ========
 *
 */

/* this define must precede inclusion of any xdc header file */
#define Registry_CURDESC Umsg__Desc
#define MODULE_NAME "Umsg"

#include <xdc/std.h>
#include <xdc/runtime/Diags.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Log.h>
#include <xdc/runtime/Memory.h>
#include <xdc/runtime/Registry.h>

#include <ti/ipc/MultiProc.h>
#include <ti/ipc/NameServer.h>
#include <ti/ipc/SharedRegion.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/hal/Hwi.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>

/* this module's header files */
#include "Umsg.h"
#include "UmsgInternal.h"

#define SYSCFG0_ADDR    0x01C14000
#define SYSCFG0_SIZE    0x1000
#define CHIPSIG         0x174
#define CHIPSIG_CLR     0x178
#define ARM_DSP_BIT     3               /* SYSCFG_CHIPINT3, DSP EVT 67  */
#define DSP_ARM_BIT     1               /* SYSCFG_CHIPINT1  ARM INT 29  */

/* event ids associated with inter-core interrupts */
#define DSP2ARM_CHIPINT0        28
#define DSP2ARM_CHIPINT1        29
#define ARM2DSP_CHIPINT2        5
#define ARM2DSP_CHIPINT3        67
#define DSPINTVECTID            6

/* private data */
Registry_Desc           Registry_CURDESC;
extern Umsg_Module      Umsg_mod;

typedef struct {
    UInt32              recvdIntrCount; /* received interrupt count     */
    Umsg_IsrState *     isrState;       /* reader's isr state           */
} Umsg_HwiCtx;

static Void Umsg_hwiFxn(UArg arg);

static Hwi_Handle       Umsg_hwi = NULL;
static Umsg_HwiCtx      Umsg_ctx;

typedef struct {
    Semaphore_Handle    sem;
    Semaphore_Struct    semObj;
} WaitObj;

static WaitObj wait_ary[32];


/*
 *  ======== Umsg_destroy ========
 */
Void Umsg_destroy(Void)
{
    IArg key;

    key = Umsg_enterGate();

    if (--Umsg_mod.refCount > 0) {
        goto leave; /* Umsg_mod still in use */
    }

    /* disable our specific interrupt */
    Hwi_disableInterrupt(DSPINTVECTID);

    /* disable global interrupts */
    key = Hwi_disable();

    Hwi_delete(&Umsg_hwi);

    /* restore global interrupts */
    Hwi_restore(key);

    /* delete the name server instance */
    NameServer_delete(&Umsg_mod.nameServer);

    /*
     * Note that there isn't a Registry_removeModule() yet:
     *     https://bugs.eclipse.org/bugs/show_bug.cgi?id=315448
     *
     * ... but this is where we'd call it.
     */
leave:
    Umsg_leaveGate(key);
}

/*
 *  ======== Umsg_enterGate ========
 */
IArg Umsg_enterGate(Void)
{
    /* TODO */
    return(0);
}

/*
 *  ======== Umsg_leaveGate ========
 */
Void Umsg_leaveGate(IArg key)
{
    /* TODO */
}

/*
 *  ======== Umsg_setup ========
 */
Int Umsg_setup(Void)
{
    Registry_Result     result;
    IArg                key;
    NameServer_Params   nsParams;
    Hwi_Params          hwiParams;
    SharedRegion_SRPtr  srPtr;
    UInt16              procAry[2];
    UInt16              readerProc;
    UInt16              writerProc;
    Error_Block         eb;
    Int                 status = Umsg_S_SUCCESS;

    Error_init(&eb);
    key = Umsg_enterGate();

    if (Umsg_mod.refCount >= 1) {
        /* nothing to be done, Umsg_mod already setup */
        goto leave;
    }

    /* register with xdc.runtime to get a diags mask */
    result = Registry_addModule(&Registry_CURDESC, MODULE_NAME);

    if ((result != Registry_SUCCESS) && (result != Registry_ALREADY_ADDED)) {
        Umsg_error0("Umsg_setup: Registry_addModule() failed");
        status = Umsg_E_FAIL;
        goto leave;
    }

    /* create the umsg name server */
    NameServer_Params_init(&nsParams);
    nsParams.maxRuntimeEntries = Umsg_MAXNSENTRIES;
    nsParams.maxNameLen = Umsg_MAXNSNAMELEN;
    nsParams.maxValueLen = sizeof(UInt32);

    Umsg_mod.nameServer = NameServer_create(Umsg_NAMESERVER, &nsParams);

    if (Umsg_mod.nameServer == NULL) {
        Umsg_error0("Umsg_setup: NameServer_create() failed");
        status = Umsg_E_FAIL;
        goto leave;
    }

    /* get the umsg system state address from name server */
    procAry[0] = MultiProc_getId("HOST");
    procAry[1] = MultiProc_INVALIDID;

    status = NameServer_getUInt32(Umsg_mod.nameServer, Umsg_SYSSTATE, &srPtr,
            procAry);

    if (status < 0) {
        Umsg_error1("Umsg_setup: name server does not have %s object",
                (IArg)Umsg_SYSSTATE);
        status = Umsg_E_FAIL;
        goto leave;
    }
    else {
        status = Umsg_S_SUCCESS;
    }
    Umsg_mod.sys = SharedRegion_getPtr(srPtr);

    /* setup the interrupt handler context */
    readerProc = MultiProc_self();
    writerProc = MultiProc_getId("HOST");
    Umsg_ctx.recvdIntrCount = 0;
    Umsg_ctx.isrState = &(Umsg_mod.sys->isrSt[readerProc][writerProc]);

    /* register interrupt for communication between ARM and DSP */
    Hwi_Params_init(&hwiParams);
    hwiParams.enableInt = FALSE;
    hwiParams.maskSetting = Hwi_MaskingOption_SELF;
    hwiParams.arg = (UArg)(&Umsg_ctx);
    hwiParams.eventId = ARM2DSP_CHIPINT3;

    key = Hwi_disable();
    Umsg_hwi = Hwi_create(DSPINTVECTID, Umsg_hwiFxn, &hwiParams, &eb);
    Hwi_restore(key);

    if (Error_check(&eb)) {
        Umsg_error1("Umsg_setup: failed to register for interrupt id=%d",
                DSPINTVECTID);
        status = Umsg_E_FAIL;
        goto leave;
    }

    /* enable our specific interrupt */
    Hwi_enableInterrupt(DSPINTVECTID);

leave:
    /* success, increment reference count */
    if (status >= 0) {
        Umsg_mod.refCount++;
    }

    /* error handling */
    else {
        /* should unregister diags mask */

        /* release the name server instance */
        if (Umsg_mod.nameServer != NULL) {
            NameServer_delete(&Umsg_mod.nameServer);
        }
    }

    Umsg_leaveGate(key);
    return(status);
}

/*
 *  ======== Umsg_Device_cancelWaitIndex ========
 */
Void Umsg_Device_cancelWaitIndex(Int waitIndex)
{

    /* destruct the semaphore */
    wait_ary[waitIndex].sem = NULL;
    Semaphore_destruct(&(wait_ary[waitIndex].semObj));
}

/*
 *  ======== Umsg_hwiFxn ========
 */
static Void Umsg_hwiFxn(UArg arg)
{
    Umsg_HwiCtx *       ctx;
    volatile UInt32 *   addr;
    Umsg_IsrState *     isrState;
    Int                 waitIndex;

    /* setup local context */
    ctx = (Umsg_HwiCtx *)arg;
    isrState = ctx->isrState;

    /* clear the interrupt at the source (CHIPSIG_CLR register) */
    addr = (UInt32 *)(SYSCFG0_ADDR + CHIPSIG_CLR);
    *addr = (1 << ARM_DSP_BIT);

    /* dequeue wait index and wakeup reader thread */
    while (ctx->recvdIntrCount != isrState->count) {
        ctx->recvdIntrCount++;
        waitIndex = isrState->isrAry[isrState->isrQue.head];
        isrState->isrQue.head =
                (isrState->isrQue.head + 1) % isrState->isrQue.count;

        /* post the counting semaphore for each received message */
        Semaphore_post(wait_ary[waitIndex].sem);
    }
}

/*
 *  ======== Umsg_Device_raiseInterrupt ========
 */
Void Umsg_Device_raiseInterrupt(Void)
{
    volatile UInt32 *addr;

    /* raise the interrupt */
    addr = (UInt32 *)(SYSCFG0_ADDR + CHIPSIG);
    *addr = (1 << DSP_ARM_BIT);

    /* lower the interrupt (hack to prevent double interrupt) */
    addr = (UInt32 *)(SYSCFG0_ADDR + CHIPSIG_CLR);
    *addr = (1 << DSP_ARM_BIT);
}

/*
 *  ======== Umsg_Device_reserveWaitIndex ========
 */
Void Umsg_Device_reserveWaitIndex(Int waitIndex)
{
    Semaphore_Params semParams;

    /* construct a counting semaphore */
    Semaphore_Params_init(&semParams);
    semParams.mode = Semaphore_Mode_COUNTING;
    Semaphore_construct(&(wait_ary[waitIndex].semObj), 0, &semParams);
    wait_ary[waitIndex].sem = Semaphore_handle(&(wait_ary[waitIndex].semObj));
}

/*
 *  ======== Umsg_Device_wait ========
 */
Void Umsg_Device_wait(UInt32 count, Int waitIndex)
{
    Semaphore_pend(wait_ary[waitIndex].sem, BIOS_WAIT_FOREVER);
}
