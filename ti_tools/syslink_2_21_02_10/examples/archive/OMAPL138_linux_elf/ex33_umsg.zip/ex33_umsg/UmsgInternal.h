/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== UmsgInternal.h ========
 *
 */

#ifndef UmsgInternal__include
#define UmsgInternal__include

#include <ti/ipc/HeapMemMP.h>
#include <ti/ipc/NameServer.h>
#include <ti/ipc/SharedRegion.h>

#if defined (__cplusplus)
extern "C" {
#endif


/* queue management */
#define WQSZ    8               /* number of elements in wait queue     */
#define PCNT    2               /* processor count                      */

typedef struct {
    UInt32 *    array;          /* array of elements (srptr)    */
    UInt32      head;           /* firts element in queue       */
    UInt32      tail;           /* next free slot in queue      */
    UInt32      count;          /* number of elements in queue  */
} Queue;


/* wait index management */
#define WI_MAX  32              /* use multiples of 32          */
#define WI_MAS (WI_MAX / 32)    /* wait index mask array size   */


/*
 *  ======== Umsg_Block ========
 *  Shared data structure containing inbox, message pool, etc
 *
 *  shared region layout of umsg block
 *  ----------------------------------------------------------
 *  struct Umsg_Block   - embedded structure
 *  UInt32[]            - inbox array memory
 *  UInt32[]            - free array memory
 *  UInt32[]            - message pool array memory
 */
typedef struct {
    Queue       inbox;          /* new messages to be picked up         */
    Queue       free;           /* free messages in the pool            */
    Int32       waitIndex;      /* used by ISR to wake waiting task     */
    Int32       writer;         /* creator's role                       */
    UInt16      createProcId;   /* create processor id                  */
    UInt16      openProcId;     /* open processor id                    */
} Umsg_Block;

/*
 *  ======== UmsgIsrState ========
 */
typedef struct {
    UInt32      count;          /* number of interrupts sent            */
    Queue       isrQue;         /* receiving queue, contains wait index */
    UInt32      isrAry[WQSZ];   /* receiving queue array                */
} Umsg_IsrState;

/*
 *  ======== Umsg_SysState ========
 *  The module system wide state stored in shared memory
 */
typedef struct {
    Umsg_IsrState isrSt[PCNT][PCNT]; /* isr state by [reader][write] procId */
    UInt32 wiMskAry[PCNT][WI_MAS];   /* track used wait indexes */
} Umsg_SysState;

/*
 *  ======== Umsg_Object ========
 *  The instance state object
 */
typedef struct {
    Umsg_Block *block;          /* umsg block (local addresss)          */
    SizeT       size;           /* size of umsg block (bytes)           */
    Queue *     inboxQue;       /* inbox ptr (local address)            */
    UInt32 *    inboxAry;       /* inbox array (local address)          */
    UInt32      msgCount;       /* number of received messages          */
    Queue *     freeQue;        /* free list (local address)            */
    UInt32 *    freeAry;        /* free array (local address)           */
    Ptr         heap;           /* shared region heap                   */
    Ptr         key;            /* name server key                      */
    UInt16      regionId;       /* shared region id                     */
    Umsg_IsrState *dstIsrState; /* destination processor's isr queue    */
} Umsg_Object;

typedef struct {
    Int                 refCount;
    HeapMemMP_Handle    heap;           /* SR_0 heap                    */
    Umsg_SysState *     sys;
    UInt32 *            count;  /* number of sent interrupts            */
    Queue *             que;    /* inbound queue (local address)        */
    UInt32 *            ary;    /* inbount array (local address)        */
    NameServer_Handle   nameServer;
    Ptr                 sysKey;
} Umsg_Module;

#define Umsg_NAMESERVER         "ti.umsg"
#define Umsg_MAXNSENTRIES       32
#define Umsg_MAXNSNAMELEN       32
#define Umsg_INAME              "iname"
#define Umsg_SYSSTATE           "umsg_sys"

IArg Umsg_enterGate(Void);
Void Umsg_leaveGate(IArg key);

Void Umsg_Device_cancelWaitIndex(Int waitIndex);
Void Umsg_Device_destroy(Void);
Void Umsg_Device_raiseInterrupt(Void);
Void Umsg_Device_reserveWaitIndex(Int waitIndex);
Int Umsg_Device_setup(Void);
Void Umsg_Device_wait(UInt32 count, Int waitIndex);


/*  These macros attempt to provide a common interface for event and
 *  error logging. When building on Linux, the error logging is done
 *  with printf(); there is no event logging on Linux. On SYS/BIOS,
 *  the xdc.runtime.Log module is used for both event and error logging.
 */
#if defined(BUILD_XDC)

#include <xdc/std.h>
#include <xdc/runtime/Log.h>

#define Umsg_error0(fmt)        Log_error0(fmt)
#define Umsg_error1(fmt,a)      Log_error1(fmt, (IArg)(a))
#define Umsg_error2(fmt,a,b)    Log_error2(fmt, (IArg)(a), (IArg)(b))
#define Umsg_error3(fmt,a,b,c)  Log_error3(fmt, (IArg)(a), (IArg)(b), (IArg)(c))
#define Umsg_error4(fmt,a,b,c,d) \
    Log_error4(fmt, (IArg)(a), (IArg)(b), (IArg)(c), (IArg)(d))
#define Umsg_error5(fmt,a,b,c,d,e) \
    Log_error5(fmt, (IArg)(a), (IArg)(b), (IArg)(c), (IArg)(d), (IArg)(e))

#elif defined(SYSLINK_BUILDOS_LINUX)

#include <stdio.h>

#define Log_print0(m, fmt)
#define Log_print1(m, fmt, a)
#define Log_print2(m, fmt, a, b)
#define Log_print3(m, fmt, a, b, c)
#define Log_print4(m, fmt, a, b, c, d)
#define Log_print5(m, fmt, a, b, c, d, e)

#define Umsg_error0(fmt) \
    printf("Error: %s, line %d: "fmt"\n",__FILE__,__LINE__)
#define Umsg_error1(fmt,a) \
    printf("Error: %s, line %d: "fmt"\n",__FILE__,__LINE__,(a))
#define Umsg_error2(fmt,a,b) \
    printf("Error: %s, line %d: "fmt"\n",__FILE__,__LINE__,(a),(b))
#define Umsg_error3(fmt,a,b,c) \
    printf("Error: %s, line %d: "fmt"\n",__FILE__,__LINE__,(a),(b),(c))
#define Umsg_error4(fmt,a,b,c,d) \
    printf("Error: %s, line %d: "fmt"\n",__FILE__,__LINE__,(a),(b),(c),((d))
#define Umsg_error5(fmt,a,b,c,d,e) \
    printf("Error: %s, line %d: "fmt"\n",__FILE__,__LINE__,(a),(b),(c),(d),(e))

#endif


#if defined (__cplusplus)
}
#endif
#endif /* UmsgInternal__include */
