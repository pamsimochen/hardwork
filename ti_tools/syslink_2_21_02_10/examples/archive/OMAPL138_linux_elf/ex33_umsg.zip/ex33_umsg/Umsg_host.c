/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== Umsg.c ========
 *
 */

#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include <ti/syslink/Std.h>     /* must be first */

#include <ti/ipc/HeapMemMP.h>
#include <ti/ipc/MultiProc.h>

#include <ti/syslink/utils/Memory.h>
#include <ti/syslink/ProcMgr.h>

/* this module's header files */
#include "Umsg.h"
#include "UmsgInternal.h"
#include "linux/UmsgDrvProtocol.h"

/* private data */
extern Umsg_Module      Umsg_mod;
static Int              umsg_fd = 0;


/*
 *  ======== Umsg_destroy ========
 */
Void Umsg_destroy(Void)
{
    IArg key;

    key = Umsg_enterGate();

    if (--Umsg_mod.refCount > 0) {
        goto leave; /* Umsg_mod still in use */
    }

    /* device specific */
    Umsg_Device_destroy();

    /* remove the system state key from name server */
    NameServer_removeEntry(Umsg_mod.nameServer, Umsg_mod.sysKey);

    /* delete the name server instance */
    NameServer_delete(&Umsg_mod.nameServer);

    /* free the system state object in shared memory */
    HeapMemMP_free(Umsg_mod.heap, Umsg_mod.sys, sizeof(Umsg_SysState));

leave:
    Umsg_leaveGate(key);
}

/*
 *  ======== Umsg_enterGate ========
 */
IArg Umsg_enterGate(Void)
{
    /* TODO */
    return(0);
}

/*
 *  ======== Umsg_leaveGate ========
 */
Void Umsg_leaveGate(IArg key)
{
    /* TODO */
}

/*
 *  ======== Umsg_setup ========
 */
Int Umsg_setup(Void)
{
    Int                 status = Umsg_S_SUCCESS;
    IArg                key;
    SharedRegion_SRPtr  srPtr;
    NameServer_Params   nsParams;
    Umsg_IsrState *     isrState;
    Int                 i, j;

    key = Umsg_enterGate();

    /* TODO this is only process global, need to make it system global */

    if (Umsg_mod.refCount >= 1) {
        /* nothing to be done, Umsg_mod already setup */
        goto leave;
    }

    /* create the system state object */
    Umsg_mod.heap = SharedRegion_getHeap(0);
    Umsg_mod.sys = HeapMemMP_alloc(Umsg_mod.heap, sizeof(Umsg_SysState), 0);

    if (Umsg_mod.sys == NULL) {
        Umsg_error1("Umsg_setup: out of memory, size=%d", sizeof(Umsg_SysState));
        status = Umsg_E_MEMORY;
        goto leave;
    }

    /* initialize the isr state array */
    for (i = 0; i < PCNT; i++) {
        for (j = 0; j < PCNT; j++) {
            if (i == j) {
                continue;
            }
            isrState = &(Umsg_mod.sys->isrSt[i][j]);
            isrState->count = 0;
            isrState->isrQue.head = 0;
            isrState->isrQue.tail = 0;
            isrState->isrQue.count = WQSZ;
            srPtr = SharedRegion_getSRPtr(isrState->isrAry, 0);
            isrState->isrQue.array = (UInt32 *)srPtr;
        }
    }

    /* initialize the wait index tracking array */
    for (i = 0; i < PCNT; i++) {
        for (j = 0; i < WI_MAS; i++) {
            Umsg_mod.sys->wiMskAry[i][j] = 0;
        }
    }

    /* create the umsg name server */
    NameServer_Params_init(&nsParams);
    nsParams.maxRuntimeEntries = Umsg_MAXNSENTRIES;
    nsParams.maxNameLen = Umsg_MAXNSNAMELEN;
    nsParams.maxValueLen = sizeof(UInt32);

    Umsg_mod.nameServer = NameServer_create(Umsg_NAMESERVER, &nsParams);

    if (Umsg_mod.nameServer == NULL) {
        Umsg_error0("Umsg_setup: NameServer_create() failed");
        status = Umsg_E_FAIL;
        goto leave;
    }

    /* add system state object to name server */
    srPtr = SharedRegion_getSRPtr(Umsg_mod.sys, 0);
    Umsg_mod.sysKey = NameServer_addUInt32(Umsg_mod.nameServer,
            Umsg_SYSSTATE, srPtr);

    if (Umsg_mod.sysKey == NULL) {
        Umsg_error1("Umsg_setup: unable to add %s to name server instance",
                Umsg_SYSSTATE);
        status = Umsg_E_FAIL;
        goto leave;
    }

    /* device specific runtime setup */
    status = Umsg_Device_setup();

    if (status < 0) {
        Umsg_error0("Umsg_setup: driver setup failed");
        goto leave;
    }

leave:
    /* success, increment reference count */
    if (status >= 0) {
        Umsg_mod.refCount++;
    }

    /* error handling */
    else {
        if (Umsg_mod.sysKey != NULL) {
            NameServer_removeEntry(Umsg_mod.nameServer, Umsg_mod.sysKey);
        }
        if (Umsg_mod.nameServer != NULL) {
            NameServer_delete(&Umsg_mod.nameServer);
        }
        if (Umsg_mod.sys != NULL) {
            HeapMemMP_free(Umsg_mod.heap, Umsg_mod.sys, sizeof(Umsg_SysState));
        }
    }

    Umsg_leaveGate(key);
    return(status);
}

/*
 *  ======== Umsg_Device_cancelWaitIndex ========
 */
Void Umsg_Device_cancelWaitIndex(Int waitIndex)
{
    /* currently not needed because host always creates the instance */
}

/*
 *  ======== Umsg_Device_destroy ========
 */
Void Umsg_Device_destroy(Void)
{
    Int status = 0;

    /* invoke the driver */
    status = ioctl(umsg_fd, Umsg_CMD_DESTROY, NULL);

    if (status < 0) {
        Umsg_error1("Umsg_Device_destroy: ioctl error=%d", status);
        /* must continue, cannot return error code */
    }

    /* close the umsg driver */
    close(umsg_fd);
    umsg_fd = 0;
}

/*
 *  ======== Umsg_Device_raiseInterrupt ========
 */
Void Umsg_Device_raiseInterrupt(Void)
{
    Int status;
    Umsg_CmdArgs ctx;

    /* setup the arguments */
    ctx.args.raise.key = 0x10EF;
    ctx.status = 0;

    /* invoke the driver */
    status = ioctl(umsg_fd, Umsg_CMD_RAISE, (Ptr)(&ctx));

    if (status < 0) {
        Umsg_error1("Umsg_Device_raiseInterrupt: ioctl error=%d", status);
    }
}

/*
 *  ======== Umsg_Device_reserveWaitIndex ========
 */
Void Umsg_Device_reserveWaitIndex(Int waitIndex)
{
    /* currently not needed because host always creates the instance */
}

/*
 *  ======== Umsg_Device_setup ========
 */
Int Umsg_Device_setup(Void)
{
    Int                 status = Umsg_S_SUCCESS;
    Ptr                 sysStatePA;
    ProcMgr_Handle      procHndl = NULL;
    Umsg_CmdArgs        ctx;

    /* open the umsg driver */
    umsg_fd = open(UMSG_DEV_NAME, O_SYNC | O_RDWR);

    if (umsg_fd < 0) {
        Umsg_error1("Umsg_Device_setup: open() error=%d", umsg_fd);
        status = Umsg_E_OSFAIL;
        goto leave;
    }

    /* set flag to close file descriptor on exec */
    status = fcntl(umsg_fd, F_SETFD, FD_CLOEXEC);

    if (status < 0) {
        Umsg_error1("Umsg_Device_setup: fcntl() error=%d", status);
        status = Umsg_E_OSFAIL;
        goto leave;
    }

    /* pass physical address of Umsg_SysState object to driver */
    status = ProcMgr_open(&procHndl, MultiProc_getId("DSP"));

    if (status < 0) {
        Umsg_error1("Umsg_Device_setup: ProcMgr_open() error=%d", status);
        status = Umsg_E_FAIL;
        goto leave;
    }

    status = ProcMgr_translateAddr(procHndl, &sysStatePA,
            ProcMgr_AddrType_MasterPhys, (Ptr)(Umsg_mod.sys),
            ProcMgr_AddrType_MasterUsrVirt);

    if (status < 0) {
        Umsg_error2("Umsg_Device_setup: translate error=%d, addr=0x%p",
                status, Umsg_mod.sys);
        status = Umsg_E_FAIL;
        goto leave;
    }

    ProcMgr_close(&procHndl);

    /* driver setup */
    ctx.args.setup.sysStatePA = (unsigned int)sysStatePA;
    ctx.status = 0;

    status = ioctl(umsg_fd, Umsg_CMD_SETUP, (Ptr)(&ctx));

    if (status < 0) {
        Umsg_error1("Umsg_Device_setup: ioctl() error=%d", status);
        status = Umsg_E_OSFAIL;
        goto leave;
    }

    /* check api return status */
    status = ctx.status;

    if (status < 0) {
        Umsg_error1("Umsg_Device_setup: driver error=%d", status);
        status = Umsg_E_FAIL;
        goto leave;
    }

leave:
    /* error handling */
    if (status < 0) {

        /* close the proc handle */
        if (procHndl != NULL) {
            ProcMgr_close(&procHndl);
        }

        /* close the driver */
        if (umsg_fd > 0) {
            close(umsg_fd);
            umsg_fd = 0;
        }
    }

    return(status);
}

/*
 *  ======== Umsg_Device_wait ========
 */
Void Umsg_Device_wait(UInt32 count, Int waitIndex)
{
    Int status;
    Umsg_CmdArgs ctx;

    /* setup the arguments */
    ctx.args.get.count = count;
    ctx.args.get.wait_index = waitIndex;
    ctx.status = 0;

    /* invoke the driver */
    status = ioctl(umsg_fd, Umsg_CMD_WAIT, (Ptr)(&ctx));

    if (status < 0) {
        Umsg_error1("Umsg_Device_wait: ioctl() error=%d", status);
    }
}
