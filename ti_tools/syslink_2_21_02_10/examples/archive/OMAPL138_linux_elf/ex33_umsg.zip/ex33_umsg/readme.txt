#
#  ======== readme.txt ========
#

ex33_umsg - Inter-processor Unidirectional Messaging (Umsg)


Overview
=========================================================================
This example builds a library which implements the Umsg interface. It also
builds a Linux kernel driver needed by the umsg library. See the ex34_radar
example on how to build an application which uses the umsg library.


Build Instructions
=========================================================================
Prompt: [host] - run these commands on your build host (Linux)
Prompt: [target] - run these commands on your embedded system

 1. Setup a development area. A typical setup might look like this.

    testbench/
     |_ lab101/
         |_ Depot/
         |   |_ bios_m_mm_pp_bb/
         |   |_ cs_arm_vv_bb/
         |   |_ ipc_m_mm_pp_bb/
         |   |_ linux_m_m_pp/
         |   |_ syslink_m_mm_pp_bb/
         |   |_ ti_c6x_m_m_p/
         |   |_ xdctools_m_mm_pp_bb/
         |_ Downloads/
         |   |_ syslink_m_mm_pp_bb.tar.zip
         |_ work/
             |_ ex33_umsg/
             |_ ex34_radar/
             |_ products.mak

 2. Unpack the zip file. Look in the syslink_m_mm_pp_bb/examples/archive
    folder to find the example zip files.

    [host] unzip ex33_umsg.zip

 3. Setup the build environment. Edit products.mak and set the install paths
    as defined by your physical development area. Each example has its own
    products.mak file; you may also create a products.mak file in the parent
    directory which will be used by all examples.

    DEPOT = /testbench/lab101/Depot

    BIOS_INSTALL_DIR        = $(DEPOT)/bios_m_mm_pp_bb
    CGT_ARM_PREFIX          = $(DEPOT)/cs_arm_vv_bb/bin/arm-none-linux-gnueabi-
    IPC_INSTALL_DIR         = $(DEPOT)/ipc_m_mm_pp_bb
    SYSLINK_INSTALL_DIR     = $(DEPOT)/syslink_m_mm_pp_bb
    CGT_C674_ELF_INSTALL_DIR= $(DEPOT)/ti_c6x_m_m_p
    XDC_INSTALL_DIR         = $(DEPOT)/xdctools_m_mm_pp_bb
    LINUXKERNEL             = $(DEPOT)/linux_m_m_pp

 4. Build the example. This will build debug and release versions of the
    umsg library as well as the driver.

    [host] cd ex33_umsg
    [host] make

    Look in the following folders for the generated files.

    ex33_umsg/lib/              Debug and release libraries
    ex33_umsg/linux/            Linux kernel umsg driver

 5. Use the install goal to copy the Linux driver to your target file system.

    [host] cd ex33_umsg
    [host] make install EXEC_DIR=/target_file_system/lab101

 6. Use the load_umsg.sh script to install the umsg driver.

    [target] cd lab101/ex33_umsg/
    [target] load_umsg.sh
