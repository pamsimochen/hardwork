#!/bin/sh

set -x

rmmod umsg
