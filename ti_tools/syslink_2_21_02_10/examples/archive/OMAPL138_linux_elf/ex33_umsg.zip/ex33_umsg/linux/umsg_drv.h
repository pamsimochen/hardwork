/*
 *  Copyright (C) 2012 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; version 2 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

/*
 *  ======== umsg_drv.h ========
 *
 */
#ifndef umsg_drv__include
#define umsg_drv__include

#if defined (__cplusplus)
extern "C" {
#endif

void umsg_destroy(void);
void umsg_raise(unsigned int count);
int  umsg_setup(unsigned int sysStatePA);
void umsg_wait(unsigned int count, int wait_index);


#if defined (__cplusplus)
}
#endif
#endif /* umsg_drv__include */
