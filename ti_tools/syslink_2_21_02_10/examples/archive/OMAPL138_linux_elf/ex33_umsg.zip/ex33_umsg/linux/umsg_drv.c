/*
 *  Copyright (C) 2012 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; version 2 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

/*
 *  ======== umsg_drv.c ========
 *
 */

#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/sched.h>

#include <ti/syslink/Std.h>
#include "../UmsgInternal.h"
#include "UmsgDrvProtocol.h"
#include "umsg_drv.h"

#define SYSCFG0_ADDR    0x01C14000      /* OMAP-L1xx specific addresses */
#define SYSCFG0_SIZE    0x1000
#define CHIPSIG         0x174
#define CHIPSIG_CLR     0x178
#define ARM_DSP_BIT     3               /* SYSCFG_CHIPINT3, DSP EVT 67 */
#define DSP_ARM_BIT     1               /* SYSCFG_CHIPINT1  ARM INT 29 */

#define READER_PROC_ID  1
#define WRITER_PROC_ID  0

#define UMSG_IRQ 29


/* private functions */
static irqreturn_t umsg_isr_handler(int irq, void *ctx);
static int umsg_isr_register(int readerProc, int writerProc);
static irqreturn_t umsg_isr_thread(int irq, void *arg);
static void umsg_isr_unregister(void);

struct isr_state {
    u32                 recvdIntrCount; /* received interrupt count */
    Umsg_IsrState *     isrState;       /* reader's isr state */
};
static struct isr_state isr_state;

struct wait_state {
    u32                 count;          /* number of interrupts received */
    struct task_struct *task;           /* waiting task handle */
};
static struct wait_state wait_ary[WI_MAX]; /* wait array */

Umsg_SysState *umsg_sys = NULL;
static unsigned int SYSCFG0_base = 0;


/*
 *  ======== umsg_destroy ========
 */
void umsg_destroy(void)
{

    /* unregister the isr handler */
    umsg_isr_unregister();

    /* release the Umsg_SysState mapping */
    if (umsg_sys != NULL) {
        iounmap(umsg_sys);
        umsg_sys = NULL;
    }

    /* unmap the SYSCFG0 module */
    if (SYSCFG0_base != 0) {
        iounmap((void *)SYSCFG0_base);
        SYSCFG0_base = 0;
    }
}

/*
 *  ======== umsg_raise ========
 */
void umsg_raise(unsigned int key)
{
    volatile UInt32 *addr;

    /* raise the interrupt */
    addr = (volatile unsigned int *)(SYSCFG0_base + CHIPSIG);
    *addr = (1 << ARM_DSP_BIT);
}

/*
 *  ======== umsg_wait ========
 */
void umsg_wait(unsigned int count, int wait_index)
{
    int retval = 0;

    /* struct task_struct *current; global in linux/sched.h */
    wait_ary[wait_index].task = current;

    do {
        set_current_state(TASK_INTERRUPTIBLE);

        if (count != wait_ary[wait_index].count) {
            break;
        }

        if (signal_pending(current)) {
            retval = -ERESTARTSYS;
            break;
        }

        schedule();

    } while (1);

    __set_current_state(TASK_RUNNING);
    wait_ary[wait_index].task = NULL;
}

/*
 *  ======== umsg_isr_handler ========
 */
static irqreturn_t umsg_isr_handler(int irq, void *arg)
{
    struct isr_state *  ctx;
    volatile u32 *      addr;
    Umsg_IsrState *     isrState;
    int                 wait_index;

    /* setup local context */
    ctx = (struct isr_state *)arg;
    isrState = ctx->isrState;

    /* clear the interrupt at the source (CHIPSIG_CLR register) */
    addr = (volatile unsigned int *)(SYSCFG0_base + CHIPSIG_CLR);
    *addr = (1 << DSP_ARM_BIT);

    /* dequeue wait index and wakeup reader thread */
    while (ctx->recvdIntrCount != isrState->count) {
        ctx->recvdIntrCount++;
        wait_index = isrState->isrAry[isrState->isrQue.head];
        isrState->isrQue.head =
                (isrState->isrQue.head + 1) % isrState->isrQue.count;

        /* increment received count for given wait index */
        wait_ary[wait_index].count++;

        /* if thread waiting for message, wake it now */
        if (wait_ary[wait_index].task != NULL) {
            wake_up_process(wait_ary[wait_index].task);
        }
    }

    return(IRQ_HANDLED);
}

/*
 *  ======== umsg_isr_register ========
 */
static int umsg_isr_register(int readerProc, int writerProc)
{
    int status = 0;

    /* setup the interrupt handler context */
    isr_state.recvdIntrCount = 0;
    isr_state.isrState = &(umsg_sys->isrSt[readerProc][writerProc]);

    /* bind our isr handler to the dsp interrupt #29 */
    status = request_threaded_irq(UMSG_IRQ, umsg_isr_handler,
            umsg_isr_thread, 0, "umsg", (void *)&isr_state);

    return(status);
}

/*
 *  ======== umsg_isr_thread ========
 */
static irqreturn_t umsg_isr_thread(int irq, void *arg)
{
    printk(KERN_ALERT"umsg_isr_thread: *** should not be here ***\n");
    return(IRQ_HANDLED);
}

/*
 *  ======== umsg_isr_unregister ========
 */
static void umsg_isr_unregister(void)
{
    free_irq(UMSG_IRQ, (void *)&isr_state);
}

/*
 *  ======== umsg_setup ========
 */
int umsg_setup(unsigned int sysStatePA)
{
    int status = UMSG_DRV_S_SUCCESS;
    int i;

    /* initialize the wait array */
    for (i = 0; i < WI_MAX; i++) {
        wait_ary[i].count = 0;
        wait_ary[i].task = NULL;
    }

    /* map the SYSCFG0 module */
    SYSCFG0_base = (unsigned int)ioremap_nocache(SYSCFG0_ADDR, SYSCFG0_SIZE);

    if (SYSCFG0_base == 0) {
        printk(KERN_ALERT"umsg: Error: SYSCFG0_base map failed\n");
        status = UMSG_DRV_E_FAIL;
        goto leave;
    }

    /* Umsg_SysState contains the isr state array used by isr handler */
    umsg_sys = (Umsg_SysState *)ioremap_nocache(sysStatePA,
            sizeof(Umsg_SysState));

    if (umsg_sys == NULL) {
        status = -1;
        goto leave;
    }

    /* register the isr handler */
    umsg_isr_register(READER_PROC_ID, WRITER_PROC_ID);

leave:
    return(status);
}
