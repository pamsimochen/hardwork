/*
 *  Copyright (C) 2012 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; version 2 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

/*
 *  ======== UmsgDrvProtocol.h ========
 *
 */

#ifndef UmsgDrvProtocol__include
#define UmsgDrvProtocol__include

#include <linux/ioctl.h>

#if defined (__cplusplus)
extern "C" {
#endif


/*  ====================================================================
 *  Macros and types
 *  ====================================================================
 */
#define UMSG_DEV_NAME "/dev/umsg"

#define UMSG_DRV_S_SUCCESS      (0)     /* Umsg_S_SUCCESS       */
#define UMSG_DRV_E_FAIL         (-1)    /* Umsg_E_FAIL          */
#define UMSG_DRV_E_MEMORY       (-2)    /* Umsg_E_MEMORY        */
#define UMSG_DRV_E_WAITINDEX    (-3)    /* Umsg_E_WAITINDEX     */


/*  ====================================================================
 *  IOCTL command IDs for MessageQ
 *  ====================================================================
 */
#define UMSG_IOC_MAGIC 0xE4 /* check Documentation/ioctl/ioctl-number.txt */
#define CMD_BASE 0x34       /* leave a gap just in case */

#define Umsg_CMD_DESTROY    _IOWR(UMSG_IOC_MAGIC, CMD_BASE + 0, Umsg_CmdArgs)
#define Umsg_CMD_RAISE      _IOWR(UMSG_IOC_MAGIC, CMD_BASE + 1, Umsg_CmdArgs)
#define Umsg_CMD_SETUP      _IOWR(UMSG_IOC_MAGIC, CMD_BASE + 2, Umsg_CmdArgs)
#define Umsg_CMD_WAIT       _IOWR(UMSG_IOC_MAGIC, CMD_BASE + 3, Umsg_CmdArgs)

/*  ====================================================================
 *  command arguments
 *  ====================================================================
 */
typedef struct Umsg_CmdArgs_Tag {
    union {
        struct {
            int a;
            int b;
        } put;

        struct {
            unsigned int count;
            int wait_index;
        } get;

        struct {
            unsigned int sysStatePA;
        } setup;

        struct {
            unsigned int key;
        } raise;
    } args;

    int status;
} Umsg_CmdArgs;


#if defined (__cplusplus)
}
#endif
#endif /* UmsgDrvProtocol__include */
