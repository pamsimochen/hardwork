/*
 *  Copyright (C) 2012 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; version 2 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

/*
 *  ======== driver.c ========
 *
 */
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/types.h>
#include <asm/uaccess.h>

#include "UmsgDrvProtocol.h"    /* user mode to driver interface        */
#include "umsg_drv.h"           /* umsg driver interface                */

#define DEVICE_NAME     "umsg"
#define DEVICE_COUNT    1


/* Linux driver model */
void __exit umsg_exit(void);
int __init umsg_init(void);

long umsg_ioctl(struct file *filp, unsigned int cmd, unsigned long args);
int umsg_open(struct inode *inode, struct file *filp);
int umsg_release(struct inode *inode, struct file *filp);

/* per-driver objects */
static struct file_operations driver_fops = {
    owner:              THIS_MODULE,
    open:               umsg_open,
    release:            umsg_release,
    unlocked_ioctl:     umsg_ioctl
};

static dev_t    umsg_dev_num;           /* device number */
struct class *  umsg_class;             /* device model */

/* per-device structure, only one for umsg */
struct umsg_dev {
    struct cdev cdev;
};

static struct umsg_dev umsg_dev;


/*
 *  ======== umsg_exit ========
 */
void __exit umsg_exit(void)
{

    device_destroy(umsg_class, umsg_dev_num);

    /* remove the device from the kernel */
    cdev_del(&umsg_dev.cdev);

    /* free device numbers */
    unregister_chrdev_region(umsg_dev_num, 1);

    class_destroy(umsg_class);
}

/*
 *  ======== umsg_init ========
 */
int __init umsg_init(void)
{
    int err;
    struct device *dev;

    /* request a device major number */
    err = alloc_chrdev_region(&umsg_dev_num, 0, DEVICE_COUNT, DEVICE_NAME);

    if (err < 0) {
        err = -1;
        goto fail;
    }

    /* create sysfs entries */
    umsg_class = class_create(THIS_MODULE, DEVICE_NAME);

    if (umsg_class == NULL) {
        err = -EIO;
        goto fail;
    }

    /* initialize the device structure */
    cdev_init(&umsg_dev.cdev, &driver_fops);
    umsg_dev.cdev.owner = THIS_MODULE;

    /* register the driver with the kernel, driver is "live" after this call */
    err = cdev_add(&umsg_dev.cdev, umsg_dev_num, 1);

    if (err < 0) {
        goto fail;
    }

    /* tell udev to create /dev nodes */
    dev = device_create(umsg_class, NULL, umsg_dev_num, NULL, "umsg");

    if (dev == NULL) {
        err = -1;
        goto fail;
    }

fail:
    if (err < 0) {
        printk(KERN_ALERT "umsg_init: failed\n");
    }
    return(err);
}

/*
 *  ======== umsg_ioctl ========
 */
long umsg_ioctl(struct file *filp, unsigned int cmd, unsigned long args)
{
    int             status = 0;
    Umsg_CmdArgs    ctx;

    /* copy args from user side */
    copy_from_user(&ctx, (void *)args, sizeof(Umsg_CmdArgs));

    /* dispatch requested command */
    switch (cmd) {

        case Umsg_CMD_DESTROY:
            umsg_destroy();
            break;

        case Umsg_CMD_WAIT:
            umsg_wait(ctx.args.get.count, ctx.args.get.wait_index);
            break;

        case Umsg_CMD_RAISE:
            umsg_raise(ctx.args.raise.key);
            break;

        case Umsg_CMD_SETUP:
            status = umsg_setup(ctx.args.setup.sysStatePA);
            ctx.status = status;
            break;

        default:
            break;
    }

    /* copy args back to user side */
    copy_to_user((void *)args, &ctx, sizeof(Umsg_CmdArgs));
    return(0);
}

/*
 *  ======== umsg_open ========
 */
int umsg_open(struct inode *inode, struct file *filp)
{
    return(0);
}

/*
 *  ======== umsg_release ========
 */
int umsg_release(struct inode *inode, struct file *filp)
{
    return(0);
}

MODULE_LICENSE("GPL v2");
module_init(umsg_init);
module_exit(umsg_exit);
