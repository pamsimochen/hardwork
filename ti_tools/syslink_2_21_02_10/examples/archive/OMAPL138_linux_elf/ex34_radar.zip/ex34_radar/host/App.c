/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== App.c ========
 *
 */

/* host header files */
#include <stdio.h>
#include <unistd.h>
#include <sched.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/time.h>

/* package header files */
#include <ti/syslink/Std.h>     /* must be first */

#include <ti/ipc/MultiProc.h>
#include <ti/ipc/Notify.h>

/* local header files */
#include <ex33_umsg/Umsg.h>
#include "App.h"
#include "../shared/AppProtocol.h"
#include "../shared/ServerProtocol.h"

/* module structure */
typedef struct {
    UInt16              remoteProcId;
    Umsg_Handle         ctrlMsgSend;        // Umsg instance (ARM to DSP)
    Umsg_Handle         ctrlMsgRecv;        // Umsg instance (DSP to ARM)
    Umsg_Handle         dataMsgRecv;        // Umsg instance (DSP to ARM)
    sem_t               doneSem;            // slave done synchronizer
    Int                 priNorm;            // original process priority
    Int                 schedNorm;          // original scheduling policy
} App_Module;

/* private data */
static App_Module       Module;
static String           Mod_file = __FILE__;
static Int              Mod_line = 0;

/* private functions */
static Int App_enableRealTime(Void);
static Int App_disableRealTime(Void);
Void App_notifyCB(UInt16 procId, UInt16 lineId, UInt32 eventId, UArg arg,
        UInt32 payload);


/*
 *  ======== App_destroy ========
 *  Wait until the slave has closed the umsg instances. The slave will
 *  signal the semaphore to release this thread.
 */
Int App_destroy(Void)
{
    Int status = 0;

    /* wait here until slave is done */
    sem_wait(&Module.doneSem);

    /* unregister notify callback */
    Notify_unregisterEventSingle(Module.remoteProcId, Server_LINE_ID,
            Server_EVENT_ID);

    /* finalize the semaphore */
    sem_destroy(&Module.doneSem);

    /* delete the umsg instances */
    Umsg_delete(&Module.dataMsgRecv);
    Umsg_delete(&Module.ctrlMsgRecv);
    Umsg_delete(&Module.ctrlMsgSend);

    /* finalize the Umsg_Module */
    Umsg_destroy();

    return(status);
}

/*
 *  ======== App_disableRealTime ========
 *  Restore the normal scheduling policy and priority.
 */
Int App_disableRealTime(Void)
{
    Int status;
    struct sched_param schedParams;

    /* unlock memory pages */
    munlockall();

    /* restore original priority and scheduling policy */
    schedParams.sched_priority = Module.priNorm;

    status = sched_setscheduler(0, Module.schedNorm, &schedParams);

    if (status < 0) {
        printf("Error: file=%s, line=%d, App_disableRealTime: error=%d\n",
                __FILE__, __LINE__, status);
    }

    return(status);
}

/*
 *  ======== App_enableRealTime ========
 *  Improve execution performance by locking memory pages, changing
 *  scheduling policy to FIFO, and raising the priority.
 */
Int App_enableRealTime(Void)
{
    Int status;
    struct sched_param schedParams;

    /* lock memory pages in RAM */
    status = mlockall(MCL_CURRENT | MCL_FUTURE);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* save current schedule policy */
    Module.priNorm = getpriority(PRIO_PROCESS, 0);
    Module.schedNorm = sched_getscheduler(0);

    /* enable real-time shedule policy */
    schedParams.sched_priority = 45;

    status = sched_setscheduler(0, SCHED_FIFO, &schedParams);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

leave:
    /* report error */
    if (status < 0) {
        printf("Error: App_enableRealTime: error=%d, file=%s, line=%d\n",
                status, Mod_file, Mod_line);
    }
    return(status);
}

/*
 *  ======== App_notifyCB ========
 */
Void App_notifyCB(UInt16 procId, UInt16 lineId, UInt32 eventId, UArg arg,
        UInt32 payload)
{
    App_Module *mod = (App_Module*)arg;

    /* ignore no-op events */
    if (payload == Server_Notify_NOP) {
        return;
    }
    else if (payload == Server_Notify_DONE) {
        sem_post(&mod->doneSem);
    }
    else {
        /* TODO: error */
    }
}

/*
 *  ======== App_run ========
 */
Int App_run(Int num, Int rate)
{
    Int                 status;
    UInt                dataMsgCnt = 0;
    UInt                ctrlMsgCnt = 0;
    Server_CtrlMsg *    cmsg;
    Server_DataMsg *    dmsg;
    Bool                running = TRUE;
    UInt32              tsMin = 0xFFFFFFFF;
    UInt32              tsMax = 0;
    UInt32              tsAvg;
    UInt32              delta = 0;
    UInt32              load = 0;
    UInt32              tsLog[20+1];
    Int                 logHead = 0;
    Int                 logTail = 0;
    Int                 logSize = 20+1;
    Bool                logFull = FALSE;
    UInt32              tsTotal = 0;
    struct timeval      tv0, tv1;
    UInt32              sec, usec;

    printf("--> App_run: num=%d, rate=%d\n", num, rate);
    printf("App_run: ctrl msg times are round trip: ARM --> DSP --> ARM\n");

    /* enable real-time mode */
    status = App_enableRealTime();

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* send the start command */
    cmsg = (Server_CtrlMsg *)Umsg_alloc(Module.ctrlMsgSend);
    cmsg->cmd = Server_Cmd_START;
    cmsg->num = num;
    cmsg->rate = rate;
    status = Umsg_put(Module.ctrlMsgSend, cmsg);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* wait for reply message */
    cmsg = (Server_CtrlMsg *)Umsg_get(Module.ctrlMsgRecv);

    if (cmsg->cmd != Server_Cmd_START) {
        status = -1;
        Mod_line = __LINE__;
        goto leave;
    }

    Umsg_free(Module.ctrlMsgRecv, cmsg);

    /* main message loop */
    do {
        /* wait for data message */
        dmsg = Umsg_get(Module.dataMsgRecv);
        dataMsgCnt++;
        Umsg_free(Module.dataMsgRecv, dmsg);

        /* send control message every five data messages */
        if ((dataMsgCnt % 5) == 0) {

            /* latch the current timestamp */
            gettimeofday(&tv0, NULL);

            /* send a control message */
            cmsg = (Server_CtrlMsg *)Umsg_alloc(Module.ctrlMsgSend);
            cmsg->cmd = Server_Cmd_UPDATE;

            status = Umsg_put(Module.ctrlMsgSend, cmsg);

            if (status < 0) {
                Mod_line = __LINE__;
                goto leave;
            }

            /* wait for reply message */
            cmsg = (Server_CtrlMsg *)Umsg_get(Module.ctrlMsgRecv);
            ctrlMsgCnt++;

            /* latch current timestamp */
            gettimeofday(&tv1, NULL);

            /* track message round trip average */
            sec = tv1.tv_sec - tv0.tv_sec;
            usec = (sec * 1000000) + tv1.tv_usec;
            delta = usec - tv0.tv_usec;
            load = cmsg->load;
            Umsg_free(Module.ctrlMsgRecv, cmsg);
            tsMin = (tsMin > delta ? delta : tsMin);
            tsMax = (tsMax < delta ? delta : tsMax);

            /* moving average over last 4 seconds (20 control messages) */
            tsTotal += delta;
            tsLog[logTail] = delta;
            logTail = (logTail + 1) % logSize;

            if (logFull) {
                tsTotal -= tsLog[logHead];
                logHead = (logHead + 1) % logSize;
            }
            else if (ctrlMsgCnt >= 20) {
                logFull = TRUE;
            }
        }

        /* give user some feedback */
        if ((dataMsgCnt % 100) == 0) {
            tsAvg = (logFull ? (UInt32)(((float)tsTotal / 20.0) + 0.5) : 0);
            printf("App_run: data msg: %6d, ctrl msg avg=%3u usec, min=%3u "
                    "max=%3u, dsp load=%2u%%\n", dataMsgCnt, tsAvg, tsMin,
                    tsMax, load);
        }

        /* check if done */
        if (dataMsgCnt == num) {
            running = FALSE;
        }

    } while (running);

    /* send the stop command */
    cmsg = (Server_CtrlMsg *)Umsg_alloc(Module.ctrlMsgSend);
    cmsg->cmd = Server_Cmd_STOP;
    status = Umsg_put(Module.ctrlMsgSend, cmsg);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* wait for acknowledgement message */
    cmsg = (Server_CtrlMsg *)Umsg_get(Module.ctrlMsgRecv);
    Umsg_free(Module.ctrlMsgRecv, cmsg);

    /* disable real-time mode */
    App_disableRealTime();

leave:
    /* report error */
    if (status < 0) {
        printf("Error: App_run: error=%d, file=%s, line=%d\n",
                status, Mod_file, Mod_line);
    }
    printf("<-- App_run: %d\n", status);
    return(status);
}

/*
 *  ======== App_setup ========
 */
Int App_setup(Void)
{
    Int         status = 0;
    Umsg_Params umsgParams;


    printf("--> App_setup:\n");

    /* initialize the App_Module object */
    Module.remoteProcId = MultiProc_getId("DSP");
    Module.ctrlMsgSend = NULL;
    Module.ctrlMsgRecv = NULL;
    Module.dataMsgRecv = NULL;

    /* initialize the done semaphore, process local */
    sem_init(&Module.doneSem, 0, 0);

    /* register for the done event */
    status = Notify_registerEventSingle(Module.remoteProcId, Server_LINE_ID,
        Server_EVENT_ID, App_notifyCB, (UArg)&Module);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* initialize the Umsg_Module object */
    status = Umsg_setup();

    if (status < 0) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    /* create the control send umsg instance */
    Umsg_Params_init(&umsgParams);
    umsgParams.msgSize = sizeof(Server_CtrlMsg);
    umsgParams.poolCount = 7;
    umsgParams.inboxCount = 3;
    umsgParams.regionId = 0;

    Module.ctrlMsgSend = Umsg_create(App_CtrlMsgSend, TRUE,
            Module.remoteProcId, &umsgParams);

    if (Module.ctrlMsgSend == NULL) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    /* create the control receive umsg instance */
    Umsg_Params_init(&umsgParams);
    umsgParams.msgSize = sizeof(Server_CtrlMsg);
    umsgParams.poolCount = 7;
    umsgParams.inboxCount = 3;
    umsgParams.regionId = 0;

    Module.ctrlMsgRecv = Umsg_create(App_CtrlMsgRecv, FALSE,
            Module.remoteProcId, &umsgParams);

    if (Module.ctrlMsgRecv == NULL) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    /* create the data receive umsg instance */
    Umsg_Params_init(&umsgParams);
    umsgParams.msgSize = sizeof(Server_DataMsg);
    umsgParams.poolCount = 5;
    umsgParams.inboxCount = 3;
    umsgParams.regionId = 0;

    Module.dataMsgRecv = Umsg_create(App_DataMsgRecv, FALSE,
            Module.remoteProcId, &umsgParams);

    if (Module.dataMsgRecv == NULL) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    /* send ready event to slave */
    do {
        status = Notify_sendEvent(Module.remoteProcId, Server_LINE_ID,
            Server_EVENT_ID, Server_Notify_READY, TRUE);

        if (status == Notify_E_EVTNOTREGISTERED) {
            sleep(1);
        }
    } while (status == Notify_E_EVTNOTREGISTERED);

leave:
    /* report error */
    if (status < 0) {
        printf("Error: App_setup: error=%d, file=%s, line=%d\n",
                status, Mod_file, Mod_line);
    }
    printf("<-- App_setup: %d\n", status);
    return(status);
}
