#
#  ======== readme.txt ========
#

ex34_radar - Illustrate umsg library between host and salve


Overview
=========================================================================
This example illustrates how to use the umsg library (provided as example
ex33_umsg) to send messages between the host and slave processors.

On the slave side, there are two tasks: 1) the control task, and 2) the
scanner task. The control task receives control messages and sends them
back to the host. The scanner task just sends data messages to the host
on a regular time slice; it does not receive any messages.

On the host side, there is one thread. In the main loop, the thread is
blocked waiting for a data message; the data messages are simply returned
to the message pool. After every 5th data message, the host thread sends
a control message to the slave and waits for the control return message.
During this time, data messages might accumulate in the inbox. Once the
control return message is received, the thread continues to pickup data
messages.

        HOST                               SLAVE
  ----------------                    ----------------

    +----------+                        +----------+
    |          |       data msgs        |          |
    |          |<-----------------------| Scanner  |
    |          |                        |          |
    |          |                        +----------+
    | Monitor  |
    |          |      control msgs      +----------+
    |          |----------------------->|          |
    |          |      return msgs       | Control  |
    |          |<-----------------------|          |
    +----------+                        +----------+


Build and Run Instructions
=========================================================================
Prompt: [host] - run these commands on your build host (Linux)
Prompt: [target] - run these commands on your embedded system

 1. Setup a development area. A typical setup might look like this.

    testbench/
     |_ lab101/
         |_ Depot/
         |   |_ bios_m_mm_pp_bb/
         |   |_ cs_arm_vv_bb/
         |   |_ ipc_m_mm_pp_bb/
         |   |_ linux_m_m_pp/
         |   |_ syslink_m_mm_pp_bb/
         |   |_ ti_c6x_m_m_p/
         |   |_ xdctools_m_mm_pp_bb/
         |_ Downloads/
         |   |_ syslink_m_mm_pp_bb.tar.zip
         |_ work/
             |_ ex33_umsg/
             |_ ex34_radar/
             |_ products.mak

 2. Unpack the zip file. Look in the syslink_m_mm_pp_bb/examples/archive
    folder to find the example zip files.

    [host] unzip ex34_radar.zip

 3. Setup the build environment. Edit products.mak and set the install paths
    as defined by your physical development area. Each example has its own
    products.mak file; you may also create a products.mak file in the parent
    directory which will be used by all examples.

    DEPOT = /testbench/lab101/Depot

    BIOS_INSTALL_DIR        = $(DEPOT)/bios_m_mm_pp_bb
    CGT_ARM_PREFIX          = $(DEPOT)/cs_arm_vv_bb/bin/arm-none-linux-gnueabi-
    IPC_INSTALL_DIR         = $(DEPOT)/ipc_m_mm_pp_bb
    SYSLINK_INSTALL_DIR     = $(DEPOT)/syslink_m_mm_pp_bb
    CGT_C674_ELF_INSTALL_DIR= $(DEPOT)/ti_c6x_m_m_p
    XDC_INSTALL_DIR         = $(DEPOT)/xdctools_m_mm_pp_bb


 4. Build the example. This will build debug and release versions of the
    executables for both the host and slave processors.

    [host] cd ex34_radar
    [host] make

    Look in the following folders for the generated files.

    ex34_radar/dsp/bin/         Debug and release executables for the slave
    ex34_radar/host/bin/        Debug and release executables for the host

    Note: the slave executables are stripped to reduce the file size. Use
    the unstripped files (*_sym.x*) with the debugger.

 5. Use the install goal to copy the executables to your target file system.

    [host] cd ex34_radar
    [host] make install EXEC_DIR=/target_file_system/lab101

 6. Use the run.sh script to run the example.

    [target] cd lab101/ex34_radar/debug
    [target] run.sh

    You should see the following output.

+ ./slaveloader startup DSP server_dsp.xe674
Attached to slave procId 0.
Loading procId 0.
Loaded file server_dsp.xe674 on slave procId 0.
Started slave procId 0.
+ ./app_host -n 500 -r 40 DSP
--> App_setup:
<-- App_setup: 0
--> App_run: num=500, rate=40
App_run: ctrl msg times are round trip: ARM --> DSP --> ARM
App_run: data msg:    100, ctrl msg avg= 66 usec, min= 60 max= 76, dsp load= 0%
App_run: data msg:    200, ctrl msg avg= 66 usec, min= 60 max= 76, dsp load= 0%
App_run: data msg:    300, ctrl msg avg= 67 usec, min= 60 max= 92, dsp load= 0%
App_run: data msg:    400, ctrl msg avg= 67 usec, min= 60 max= 92, dsp load= 0%
App_run: data msg:    500, ctrl msg avg= 66 usec, min= 60 max= 92, dsp load= 0%
<-- App_run: 0
+ ./slaveloader shutdown DSP
Stopped slave procId 0.
Unloaded slave procId 0.
Detached from slave procId 0.


Debugging with CCS
=========================================================================
Once CCS has been configured for dual-core debugging, use the following
procedure to launch your debug session.

 1. Use slaveloader to load and run the slave processor. The slave must
    be running in order for CCS to attach to it.

    [target] cd ex34_radar/debug
    [target] ./slaveloader startup DSP server_dsp.xe674

 2. In CCS, load the symbols for the slave executable (use the *_sym.x* file).
    Then attach to the slave. Set breakpoints and then let the slave run.

 3. Use the dbg.sh script to launch the host executable using gdbserver.
    It will wait for CCS to attach to it.

    [target] dbg.sh

 4. Use CCS to attach to the gdbserver session running on your target. You
    are now debugging both cores.

    If possible, end your debug session by letting the slave free-run and
    then disconnect CCS. Let the host application run to completion.

 5. Shutdown the slave with slaveloader.

    [target] ./slaveloader shutdown DSP

    At this point, you may replace either executable with a new build and
    restart your debug session.
