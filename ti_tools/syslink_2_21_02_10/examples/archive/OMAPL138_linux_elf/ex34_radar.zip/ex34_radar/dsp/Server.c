/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== Server.c ========
 *
 */

/* this define must precede inclusion of any xdc header file */
#define Registry_CURDESC Server__Desc
#define MODULE_NAME "Server"

/* xdctools header files */
#include <xdc/std.h>                    /* must be first */
#include <xdc/runtime/Assert.h>
#include <xdc/runtime/Diags.h>
#include <xdc/runtime/Error.h>
#include <xdc/runtime/Log.h>
#include <xdc/runtime/Registry.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>

/* package header files */
#include <ti/ipc/MultiProc.h>
#include <ti/ipc/Notify.h>
#include <ti/ipc/SharedRegion.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/utils/Load.h>

#include <ti/syslink/ipc/rtos/Syslink.h>


/* local header files */
#include <ex33_umsg/Umsg.h>
#include "Server.h"
#include "../shared/AppProtocol.h"
#include "../shared/ServerProtocol.h"


/* module structure */
typedef struct {
    UInt16              hostProcId;         // host processor id
    Umsg_Handle         ctrlMsgRecv;        // Umsg instance (ARM to DSP)
    Umsg_Handle         ctrlMsgSend;        // Umsg instance (DSP to ARM)
    Umsg_Handle         dataMsgSend;        // Umsg instance (DSP to ARM)
    Semaphore_Struct    readySemObj;        // semaphore object
    Semaphore_Handle    readySem;           // handle to semaphore object
    Semaphore_Struct    scannerSemObj;      // semaphore object
    Semaphore_Handle    scannerSem;         // handle to semaphore object
    Task_Handle         scannerTsk;         // scanner task
    Int                 numMsgs;            // number of scanner messages
    Int                 msgRate;            // date message rate (ms)
} Server_Module;

/* private data */
Registry_Desc           Registry_CURDESC;
static Server_Module    Module;
static Int              Mod_curInit = 0;
static String           Mod_file = __FILE__;
static Int              Mod_line = 0;

/* private functions */
#if 0
static Void Server_work(UInt delay);
#endif
Void Server_notifyCB(UInt16 procId, UInt16 lineId, UInt32 eventId, UArg arg,
        UInt32 payload);
static Void Server_scannerThrFxn(UArg arg0, UArg arg1);


/*
 *  ======== Server_destroy ========
 */
Int Server_destroy(Void)
{
    Int status = 0;

    Log_print0(Diags_ENTRY, "--> Server_destroy:");

    /* reference count the module usage */
    if (Mod_curInit-- != 1) {
        goto leave;  /* object still being used */
    }

    /* close the Umsg object */
    Umsg_close(&Module.ctrlMsgRecv);
    Umsg_close(&Module.ctrlMsgSend);
    Umsg_close(&Module.dataMsgSend);

    /* finalize the Umsg_Module */
    Umsg_destroy();

    /* send done event to host */
    Notify_sendEvent(Module.hostProcId, Server_LINE_ID,
            Server_EVENT_ID, Server_Notify_DONE, TRUE);

    /* unregister notify callback */
    Notify_unregisterEventSingle(Module.hostProcId, Server_LINE_ID,
            Server_EVENT_ID);

    /* delete the notify sync object */
    Semaphore_destruct(&Module.readySemObj);
    Module.readySem = NULL;

    /* delete the scanner task */
    Task_delete(&Module.scannerTsk);

    /* delete the scanner sync object */
    Semaphore_destruct(&Module.scannerSemObj);
    Module.scannerSem = NULL;

    Log_print0(Diags_INFO, "Server_destroy: server has shutdown");

leave:
    /* report error */
    if (status < 0) {
        Log_error3("Error: Server_destroy: error=%d, file=%s, line=%d\n",
            (IArg)status, (IArg)Mod_file, (IArg)Mod_line);
    }

    /* disable log events */
    Log_print1(Diags_EXIT, "<-- Server_delete: status=%d", (IArg)status);
    Diags_setMask(MODULE_NAME"-F");

    /*
     * Note that there isn't a Registry_removeModule() yet:
     *     https://bugs.eclipse.org/bugs/show_bug.cgi?id=315448
     *
     * ... but this is where we'd call it.
     */
    return(status);
}

/*
 *  ======== Server_notifyCB ========
 */
Void Server_notifyCB(UInt16 procId, UInt16 lineId, UInt32 eventId, UArg arg,
        UInt32 payload)
{
    Server_Module *mod = (Server_Module*)arg;

    /* ignore no-op events */
    if (payload == Server_Notify_NOP) {
        return;
    }
    else if (payload == Server_Notify_READY) {
        Semaphore_post(mod->readySem);
    }
    else {
        /* TODO: error */
    }
}

/*
 *  ======== Server_run ========
 *  Server control loop.
 *
 *  There are two tasks running: 1) the control task (this task), and
 *  2) the scanner task (Server_scannerThrFxn()). The control task
 *  receives control messages and sends them back to the host. The
 *  scanner task just sends data messages to the host on a regular time
 *  slice; it does not receive any messages.
 *
 *  The control task runs at higher priority to ensure the prompt handling
 *  of the control messages. When a control message is received, the
 *  return message is sent as quickly as possible because the host thread
 *  is waiting for the return message. Once the return message has been
 *  sent, the actions specified in the control message are actually carried
 *  out. For example, when the start command is received, the return
 *  message is sent before the start action is actually taken.
 */
Int Server_run(Void)
{
    Int                 status = 0;
    Bool                running = TRUE;
    UInt                cmd;
    Server_CtrlMsg *    cmsgIn;
    Server_CtrlMsg *    cmsgOut;

    Log_print0(Diags_ENTRY | Diags_INFO, "--> Server_run:");

    do {
        /* pre-allocate return message */
        cmsgOut = (Server_CtrlMsg *)Umsg_alloc(Module.ctrlMsgSend);

        /* wait for inbound control message */
        cmsgIn = (Server_CtrlMsg *)Umsg_get(Module.ctrlMsgRecv);
        cmd = cmsgIn->cmd;

        switch (cmd) {

            case Server_Cmd_START:
                Module.numMsgs = cmsgIn->num;
                Module.msgRate = cmsgIn->rate;

                /* fill in return message */
                cmsgOut->cmd = Server_Cmd_START;
                break;

            case Server_Cmd_STOP:
                running = FALSE;
                break;

            case Server_Cmd_UPDATE:
                /* fill in return control message */
                cmsgOut->cmd = Server_Cmd_UPDATE;
                cmsgOut->ts = Timestamp_get32();
                cmsgOut->load = Load_getCPULoad();
                break;

            default:
                /* log error */
                break;
        }

        /* send the outbound message */
        status = Umsg_put(Module.ctrlMsgSend, cmsgOut);

        if (status < 0) {
            Mod_line = __LINE__;
            goto leave;
        }

        /* free the inbound control message */
        Umsg_free(Module.ctrlMsgRecv, cmsgIn);

        /* process the command */
        switch (cmd) {

            case Server_Cmd_START:
                /* release the scanner thread */
                Semaphore_post(Module.scannerSem);
                break;

            default:
                /* log error */
                break;
        }

    } while (running);

leave:
    Log_print1(Diags_EXIT | Diags_INFO, "<-- Server_run: %d", (IArg)status);
    return(status);
}

/*
 *  ======== Server_scannerThrFxn ========
 *  Simulate a radar scanner task. Data is collected every 40 ms and
 *  sent to the host using umsg. This example simply sleeps for this
 *  period and then sends a umsg.
 */
static Void Server_scannerThrFxn(UArg arg0, UArg arg1)
{
    Int                 status;
    Int                 i;
    Server_DataMsg *    msg;
    UInt32              ts;

    /* wait here to be released */
    Semaphore_pend(Module.scannerSem, BIOS_WAIT_FOREVER);

    /* scanner main loop */
    for (i = 1; i <= Module.numMsgs; i++) {

        /* allocate outbound message */
        msg = (Server_DataMsg *)Umsg_alloc(Module.dataMsgSend);

        /* sleep for slice ticks */
#if 1
        Task_sleep(Module.msgRate);
#else
        Task_sleep(20);         /* 20 ms */
        Server_work(20000);     /* 20 ms */
#endif

        /* latch the current timestamp */
        ts = Timestamp_get32();

        /* send a data message to host */
        msg->num = i;
        msg->ts = ts;

        status = Umsg_put(Module.dataMsgSend, msg);

        if (status < 0) {
            Log_error3("Error: Server_scanner: error=%d, file=%s, line=%d\n",
                    (IArg)status, (IArg)Mod_file, (IArg)__LINE__);
        }
    }

    /* end of task, return into kernel */
}

/*
 *  ======== Server_setup ========
 */
Int Server_setup(Void)
{
    Int                 status = 0;
    Semaphore_Params    semParams;
    Registry_Result     result;
    Error_Block         eb;
    Task_Params         taskParams;

    /* reference count the module usage */
    if (Mod_curInit++ != 0) {
        goto leave;  /* already initialized */
    }

    Error_init(&eb);

    /* register with xdc.runtime to get a diags mask */
    result = Registry_addModule(&Registry_CURDESC, MODULE_NAME);
    Assert_isTrue(result == Registry_SUCCESS, (Assert_Id)NULL);

    /* enable some log events */
    Diags_setMask(MODULE_NAME"+F");
    Log_print0(Diags_ENTRY, "--> Server_setup:");

    /* initialize module state */
    Module.hostProcId = MultiProc_getId("HOST");
    Module.ctrlMsgRecv = NULL;
    Module.ctrlMsgSend = NULL;
    Module.dataMsgSend = NULL;
    Module.numMsgs = 0;

    /* create notify sync object */
    Semaphore_Params_init(&semParams);
    semParams.mode = Semaphore_Mode_BINARY;
    Semaphore_construct(&Module.readySemObj, 0, &semParams);
    Module.readySem = Semaphore_handle(&Module.readySemObj);

    /* register for the ready event */
    status = Notify_registerEventSingle(Module.hostProcId, Server_LINE_ID,
        Server_EVENT_ID, Server_notifyCB, (UArg)&Module);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* create scanner sync object */
    Semaphore_Params_init(&semParams);
    semParams.mode = Semaphore_Mode_BINARY;
    Semaphore_construct(&Module.scannerSemObj, 0, &semParams);
    Module.scannerSem = Semaphore_handle(&Module.scannerSemObj);

    /* create the scanner thread */
    Task_Params_init(&taskParams);
    taskParams.instance->name = "scanner";
    taskParams.priority = 5;
    taskParams.stackSize = 0x800;
    Module.scannerTsk = Task_create(Server_scannerThrFxn, &taskParams, &eb);

    if (Error_check(&eb)) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* wait until application sends the ready event */
    Semaphore_pend(Module.readySem, BIOS_WAIT_FOREVER);

    /* initialize the Umsg_Module object */
    status = Umsg_setup();

    if (status < 0) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    /* enable info log events for umsg module */
    /* Diags_setMask("Umsg+F"); */

    /* open the control receive umsg instance */
    status = Umsg_open(App_CtrlMsgSend, &Module.ctrlMsgRecv);

    if (status < 0) {
        Log_error1("Server_setup: Umsg_open() failed, error=%d", (IArg)status);
        status = -1;
        goto leave;
    }

    /* open the control send umsg instance */
    status = Umsg_open(App_CtrlMsgRecv, &Module.ctrlMsgSend);

    if (status < 0) {
        Log_error1("Server_setup: Umsg_open() failed, error=%d", (IArg)status);
        status = -1;
        goto leave;
    }

    /* create the data send umsg instance */
    status = Umsg_open(App_DataMsgRecv, &Module.dataMsgSend);

    if (status < 0) {
        Log_error1("Server_setup: Umsg_open() failed, error=%d", (IArg)status);
        status = -1;
        goto leave;
    }

    Log_print0(Diags_INFO, "Server_setup: server is ready");

leave:
    Log_print1(Diags_EXIT, "<-- Server_setup: status=%d", (IArg)status);
    return (status);
}

#if 0
/*
 *  ======== Server_work ========
 */
static Void Server_work(UInt delay)
{
    Types_FreqHz    freq;
    UInt32          initial;
    UInt            elapsed;

    /* get current timestamp */
    initial = Timestamp_get32();

    /* get cpu frequency (Hz) */
    Timestamp_getFreq(&freq);

    /* wait until delay (usec) has elapsed */
    do {
        elapsed = (Timestamp_get32() - initial) / (freq.lo / 1000000);
    } while (delay > elapsed);
}
#endif
