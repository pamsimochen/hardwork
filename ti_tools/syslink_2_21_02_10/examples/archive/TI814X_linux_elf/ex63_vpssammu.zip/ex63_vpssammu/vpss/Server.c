/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== Server.c ========
 *
 */

/* this define must precede inclusion of any xdc header file */
#define Registry_CURDESC Test__Desc
#define MODULE_NAME "Server"

/* xdctools header files */
#include <xdc/std.h>                    /* must be first */
#include <xdc/runtime/Assert.h>
#include <xdc/runtime/Diags.h>
#include <xdc/runtime/Log.h>
#include <xdc/runtime/Registry.h>

/* package header files */
#include <ti/ipc/MessageQ.h>
#include <ti/sysbios/BIOS.h>

/* local header files */
#include "Server.h"


/* module structure */
typedef struct {
    MessageQ_Handle     localMsgQue;            /* created locally      */
} Server_Module;

/* private data */
Registry_Desc           Registry_CURDESC;
static Server_Module    Module;
static Int              Mod_curInit = 0;
static String           Mod_file = __FILE__;
static Int              Mod_line = 0;


/*
 *  ======== Server_destroy ========
 */
Int Server_destroy(Void)
{
    Int status = 0;

    Log_print0(Diags_ENTRY, "--> Server_destroy:");

    /* reference count the module usage */
    if (Mod_curInit-- != 1) {
        goto leave;  /* object still being used */
    }

    /* delete the local message queue */
    status = MessageQ_delete(&Module.localMsgQue);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

leave:
    /* report error */
    if (status < 0) {
        Log_error3("Error: Server_destroy: error=%d, file=%s, line=%d\n",
            (IArg)status, (IArg)Mod_file, (IArg)Mod_line);
    }

    /* disable log events */
    Log_print1(Diags_EXIT, "<-- Server_delete: status=%d", (IArg)status);
    Diags_setMask(MODULE_NAME"-F");

    /*
     * Note that there isn't a Registry_removeModule() yet:
     *     https://bugs.eclipse.org/bugs/show_bug.cgi?id=315448
     *
     * ... but this is where we'd call it.
     */
    return(status);
}

/*
 *  ======== Server_run ========
 */
Int Server_run(Void)
{
    Int                 status = 0;
    Bool                running = TRUE;
    Server_Msg *        msg;
    MessageQ_QueueId    queId;

    Log_print0(Diags_ENTRY | Diags_INFO, "--> Server_run:");

    while (running) {

        /* wait for inbound message */
        status = MessageQ_get(Module.localMsgQue, (MessageQ_Msg *)&msg,
            MessageQ_FOREVER);

        if (status < 0) {
            Mod_line = __LINE__;
            goto leave;
        }

        /* process the message */
        Log_print1(Diags_INFO, "Server_run: processed cmd=0x%x", msg->cmd);

        switch (msg->cmd) {
            case Server_Cmd_HELLO:
                break;

            case Server_Cmd_PROCESS:
                break;

            case Server_Cmd_SHUTDOWN:
                running = FALSE;
                break;

            default:
                Log_error1("Server_run: unknown message command: 0x%08x",
                        (IArg)(msg->cmd));
                break;
        }

        /* send message back */
        queId = MessageQ_getReplyQueue(msg); /* type-cast not needed */
        MessageQ_put(queId, (MessageQ_Msg)msg);

    } /* while (running) */

leave:
    /* report error */
    if (status < 0) {
        Log_error3("Error: Server_run: error=%d, file=%s, line=%d\n",
            (IArg)status, (IArg)Mod_file, (IArg)Mod_line);
    }
    Log_print1(Diags_EXIT, "<-- Server_run: status=%d", (IArg)status);
    return(status);
}

/*
 *  ======== Server_setup ========
 */
Int Server_setup(Void)
{
    Int                 status = 0;
    MessageQ_Params     msgqParams;
    Registry_Result     result;

    /* reference count the module usage */
    if (Mod_curInit++ != 0) {
        goto leave;  /* already initialized */
    }

    /* register with xdc.runtime to get a diags mask */
    result = Registry_addModule(&Registry_CURDESC, MODULE_NAME);
    Assert_isTrue(result == Registry_SUCCESS, (Assert_Id)NULL);

    /* enable some log events */
    Diags_setMask(MODULE_NAME"+F");
    Log_print0(Diags_ENTRY, "--> Server_setup:");

    /* initialize module state */
    Module.localMsgQue = NULL;

    /* create local message queue (inbound messages) */
    MessageQ_Params_init(&msgqParams);

    Module.localMsgQue = MessageQ_create(Server_MsgQueName, &msgqParams);

    if (Module.localMsgQue == NULL) {
        status = -1;
        goto leave;
    }

    Log_print0(Diags_INFO,"Server_setup: Slave is ready");

leave:
    /* report error */
    if (status < 0) {
        Log_error3("Error: Server_setup: error=%d, file=%s, line=%d\n",
            (IArg)status, (IArg)Mod_file, (IArg)Mod_line);
    }
    Log_print1(Diags_EXIT, "<-- Server_setup: status=%d", (IArg)status);
    return (status);
}
