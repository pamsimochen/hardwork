#
#  ======== readme.txt ========
#

ex03_notify - basic usage of the Notify module


Overview
=========================================================================
The host sends either an App_CMD_INC_PAYLOAD or App_CMD_DEC_PAYLOAD
command to the slave. The command includes a 16 bit payload. Depending on
the command, the slave increases or decreases the payload and replies with
an App_CMD_OP_COMPLETE command which includes the updated payload. This
continues until the host sends an App_CMD_SHUTDOWN command which results in
both cores executing their cleanup procedures.


Build and Run Instructions
=========================================================================
Prompt: [host] - run these commands on your build host
Prompt: [target] - run these commands on your embedded system

 1. Setup a development area. A typical setup might look like this.

    testbench/
     |_ lab101/
         |_ Depot/
         |   |_ bios_m_mm_pp_bb/
         |   |_ cs_arm_vv_bb/
         |   |_ ipc_m_mm_pp_bb/
         |   |_ linux_m_m_pp/
         |   |_ syslink_m_mm_pp_bb/
         |   |_ ti_c6x_m_m_p/
         |   |_ xdctools_m_mm_pp_bb/
         |_ Downloads/
         |   |_ syslink_m_mm_pp_bb.tar.zip
         |_ work/
             |_ ex03_notify/

 2. Unpack the zip file. Look in the syslink_m_mm_pp_bb/examples/archive
    folder to find the example zip files.

    [host] unzip ex03_notify.zip

 3. Setup the build environment. Edit products.mak and set the install paths
    as defined by your physical development area. Each example has its own
    products.mak file; you may also create a products.mak file in the parent
    directory which will be used by all examples.

    DEPOT = /testbench/lab101/Depot

    BIOS_INSTALL_DIR        = $(DEPOT)/bios_m_mm_pp_bb
    CGT_ARM_PREFIX          = $(DEPOT)/cs_arm_vv_bb/bin/arm-none-linux-gnueabi-
    IPC_INSTALL_DIR         = $(DEPOT)/ipc_m_mm_pp_bb
    SYSLINK_INSTALL_DIR     = $(DEPOT)/syslink_m_mm_pp_bb
    CGT_C674_ELF_INSTALL_DIR= $(DEPOT)/ti_c6x_m_m_p
    XDC_INSTALL_DIR         = $(DEPOT)/xdctools_m_mm_pp_bb


 4. Build the example. This will build debug and release versions of the
    executables for both the host and slave processors.

    [host] cd ex03_notify
    [host] make

    Look in the following folders for the generated files.

    ex03_notify/dsp/bin/        Debug and release executables for the slave
    ex03_notify/host/bin/       Debug and release executables for the host

 5. Use the install goal to copy the executables to your target file system.

    [host] cd ex03_notify
    [host] make install EXEC_DIR=/target_file_system/lab101

 6. Use the run.sh script to run the example.

    [target] cd lab101/ex03_notify/debug
    [target] run.sh


Notify Driver Configuration
=========================================================================
There are two notify drivers available in SysLink and IPC. They are called
NotifyShm driver (the default) and NotifyCirc driver. Use the following
instructions to configure the NotifyCirc driver. Note that the configuration
on the slave side is device specific.

 1. Configure the notify driver in SysLink. Edit products.mak and set
    the make variable SYSLINK_NOTIFYDRIVER.

    <syslink_m_mm_pp_bb>/products.mak

    SYSLINK_NOTIFYDRIVER = NOTIFYDRIVERCIRC
    SYSLINK_TRANSPORT = TRANSPORTSHMNOTIFY

 2. Rebuild the SysLink driver. Remember to install the new syslink.ko
    on your target file system.

    cd Depot/<syslink_m_mm_pp_bb>
    make syslink

 3. Configure the notify driver in IPC. This is done in the application's
    configuration file. For this example, edit Dsp.cfg and add the following
    statements. This must be done for each dsp executable.

    ex03_notify/dsp/Dsp.cfg

    /* configure the NotifyCirc driver*/
    var NotifyCircSetup =
            xdc.useModule('ti.sdo.ipc.family.ti81xx.NotifyCircSetup');

    var Notify = xdc.useModule('ti.sdo.ipc.Notify');
    Notify.SetupProxy = NotifyCircSetup;

    var MessageQ = xdc.module('ti.sdo.ipc.MessageQ');
    MessageQ.SetupTransportProxy =
            xdc.module('ti.sdo.ipc.transports.TransportShmNotifySetup');

For more details on the notify driver configuration, follow the link below:

http://processors.wiki.ti.com/index.php/SysLink_Notify_Drivers_and_Transports
