/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== App.c ========
 *
 */

/* host header files */
#include <stdio.h>
#include <unistd.h>

/* package header files */
#include <ti/syslink/Std.h>     /* must be first */
#include <ti/ipc/HeapBufMP.h>
#include <ti/ipc/MessageQ.h>

/* local header files */
#include "../dsp/Server.h"
#include "App.h"


/* module structure */
typedef struct {
    HeapBufMP_Handle    msgHeap;        /* created locally      */
    MessageQ_Handle     hostQue;        /* created locally      */
    MessageQ_QueueId    dspQue;         /* opened remotely      */
    UInt16              heapId;         /* MessageQ heapId      */
} App_Module;


/* private data */
static App_Module       Module;
static Int              Mod_curInit = 0;
static String           Mod_file = __FILE__;
static Int              Mod_line = 0;


/*
 *  ======== App_destroy ========
 */
Int App_destroy(Void)
{
    Int         status = 0;
    Server_Msg *msg;

    printf("--> App_destroy:\n");

    /* reference count the module usage */
    if (Mod_curInit-- != 1) {
        goto leave;  /* object still being used */
    }

    /* send the shutdown message */
    msg = (Server_Msg *)MessageQ_alloc(Module.heapId, sizeof(Server_Msg));

    if (msg == NULL) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    MessageQ_setReplyQueue(Module.hostQue, (MessageQ_Msg)msg);
    msg->cmd = Server_Cmd_SHUTDOWN;
    MessageQ_put(Module.dspQue, (MessageQ_Msg)msg);

    /* wait for return message */
    status = MessageQ_get(Module.hostQue, (MessageQ_Msg *)&msg,
        MessageQ_FOREVER);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    MessageQ_free((MessageQ_Msg)msg);

    /* close remote message queue */
    status = MessageQ_close(&Module.dspQue);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* delete the local message queue */
    status = MessageQ_delete(&Module.hostQue);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* unregister heap with MessageQ */
    status = MessageQ_unregisterHeap(App_MsgHeapId);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* delete the message heap */
    status = HeapBufMP_delete(&Module.msgHeap);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

leave:
    /* report error */
    if (status < 0) {
        printf("Error: App_destroy: error=%d, file=%s, line=%d\n",
            status, Mod_file, Mod_line);
    }
    printf("<-- App_destroy: status=%d\n", status);
    return(status);
}

/*
 *  ======== App_run ========
 */
Int App_run(Void)
{
    Int         status;
    Server_Msg *msg;
    Int         i;

    printf("--> App_run:\n");

    /* main loop */
    for (i = 1; i <= 5; i++) {

        printf("App_run: loop=%d\n", i);

        /* allocate message */
        msg = (Server_Msg *)MessageQ_alloc(Module.heapId, sizeof(Server_Msg));

        if (msg == NULL) {
            Mod_line = __LINE__;
            status = -1;
            goto leave;
        }

        /* set the return address in the message header */
        MessageQ_setReplyQueue(Module.hostQue, (MessageQ_Msg)msg);

        /* execute Fxn01 */
        msg->cmd = Server_Cmd_FXN01;
        msg->a = 2;
        printf("App_run: sending message for Server_Fxn_01\n");

        MessageQ_put(Module.dspQue, (MessageQ_Msg)msg);

        status = MessageQ_get(Module.hostQue, (MessageQ_Msg *)&msg,
            MessageQ_FOREVER);

        if (status < 0) {
            Mod_line = __LINE__;
            goto leave;
        }

        printf("App_run: x=%d (expected 21)\n", msg->x);

        /* execute Fxn02 */
        msg->cmd = Server_Cmd_FXN02;
        msg->a = 3;
        printf("App_run: sending message for Server_Fxn_02\n");

        MessageQ_put(Module.dspQue, (MessageQ_Msg)msg);

        status = MessageQ_get(Module.hostQue, (MessageQ_Msg *)&msg,
            MessageQ_FOREVER);

        if (status < 0) {
            Mod_line = __LINE__;
            goto leave;
        }

        printf("App_run: x=%d (expected 61)\n", msg->x);

        /* free the message */
        MessageQ_free((MessageQ_Msg)msg);
    }

leave:
    /* report error */
    if (status < 0) {
        printf("Error: App_run: error=%d, file=%s, line=%d\n",
            status, Mod_file, Mod_line);
    }
    printf("<-- App_run: %d\n", status);
    return(status);
}

/*
 *  ======== App_setup ========
 */
Int App_setup(Void)
{
    Int                 status = 0;
    HeapBufMP_Params    heapParams;
    MessageQ_Params     msgqParams;
    Server_Msg *        msg;

    printf("--> App_setup:\n");

    /* reference count the module usage */
    if (Mod_curInit++ != 0) {
        goto leave;  /* already initialized */
    }

    /* initialize module state */
    Module.msgHeap = NULL;
    Module.hostQue = NULL;
    Module.dspQue = MessageQ_INVALIDMESSAGEQ;
    Module.heapId = App_MsgHeapId;

    /* create heap for messages */
    HeapBufMP_Params_init(&heapParams);
    heapParams.name = App_MsgHeapName;
    heapParams.regionId = App_MsgHeapSrId;
    heapParams.blockSize = 128;
    heapParams.numBlocks = 10;

    Module.msgHeap = HeapBufMP_create(&heapParams);

    if (Module.msgHeap == NULL) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    /* register heap with MessageQ */
    status = MessageQ_registerHeap((Ptr)(Module.msgHeap), App_MsgHeapId);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* create local message queue (inbound messages) */
    MessageQ_Params_init(&msgqParams);

    Module.hostQue = MessageQ_create(App_MsgQueName, &msgqParams);

    if (Module.hostQue == NULL) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    /* open the remote message queue, loop until queue is available */
    do {
        status = MessageQ_open(Server_MsgQueName, &Module.dspQue);
        if (status == MessageQ_E_NOTFOUND) {
            sleep(1);
        }
    } while (status == MessageQ_E_NOTFOUND);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    /* send hello message */
    msg = (Server_Msg *)MessageQ_alloc(Module.heapId, sizeof(Server_Msg));

    if (msg == NULL) {
        Mod_line = __LINE__;
        status = -1;
        goto leave;
    }

    MessageQ_setReplyQueue(Module.hostQue, (MessageQ_Msg)msg);
    msg->cmd = Server_Cmd_HELLO;
    MessageQ_put(Module.dspQue, (MessageQ_Msg)msg);

    /* wait for return message */
    status = MessageQ_get(Module.hostQue, (MessageQ_Msg *)&msg,
        MessageQ_FOREVER);

    if (status < 0) {
        Mod_line = __LINE__;
        goto leave;
    }

    MessageQ_free((MessageQ_Msg)msg);

leave:
    /* report error */
    if (status < 0) {
        printf("Error: App_setup: error=%d, file=%s, line=%d\n",
            status, Mod_file, Mod_line);
    }
    printf("<-- App_setup: status=%d\n", status);
    return(status);
}
