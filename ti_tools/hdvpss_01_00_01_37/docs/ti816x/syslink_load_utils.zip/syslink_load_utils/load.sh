
insmod syslink.ko TRACE=1 TRACEFAILURE=1
