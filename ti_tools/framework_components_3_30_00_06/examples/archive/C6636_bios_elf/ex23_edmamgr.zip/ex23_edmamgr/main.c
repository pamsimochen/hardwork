/*
 * (C) Copyright 2013, Texas Instruments Incorporated.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <xdc/std.h>
#include <xdc/runtime/System.h>

#include <string.h>

#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/family/c66/Cache.h>

#include <ti/sysbios/knl/Task.h>

//#define FC_TRACE
#ifdef FC_TRACE
#include <ti/sdo/fc/global/FCSettings.h>
#include <xdc/runtime/Diags.h>
#endif

#include <ti/sdo/fc/edmamgr/edmamgr.h>

#include "edmamgr_test.h"

extern cregister volatile unsigned int DNUM;

/*********************************************************************************
 * FUNCTION PURPOSE: trap exception
 *********************************************************************************
  DESCRIPTION:      This function traps exception
  Parameters :      Inputs: statement   : statement for if check
                            core_id     : core ID
                            error       : error to be printed out
********************************************************************************/
void app_assert(int32_t statement, int32_t core_id, const char *error)
{
  volatile int32_t dbg_halt = 1;

  if(!statement) {
    System_printf("%s (%d)\n",error,core_id);
    while(dbg_halt);
  }
}

/* Base and size of DDR3 */
#define EXT_MEM_BASE (0x80000000)
#define EXT_MEM_SIZE (0x20000000)
/*********************************************************************************
 * FUNCTION PURPOSE: configure cache
 *********************************************************************************
  DESCRIPTION:      This function configure cache, including L1D cache size
                    L1P cache size, L2 cache size, and DDR MAR settings
********************************************************************************/
void cache_config(void)
{

    Cache_Size size;
    UInt32 mar;

    size.l1pSize  = Cache_L1Size_32K; /* L1P cache size */
    size.l1dSize  = Cache_L1Size_32K; /* L1D cache size */
    size.l2Size   = Cache_L2Size_64K; /* L2  cache size */
    Cache_setSize(&size);

    mar = Cache_getMar((Ptr *)EXT_MEM_BASE) | ti_sysbios_family_c66_Cache_PC |
                                              ti_sysbios_family_c66_Cache_PFX;
    Cache_setMar((Ptr *)EXT_MEM_BASE, EXT_MEM_SIZE, mar);

    Cache_wbInvAll();
}

uint8_t input[BUF_SIZE];
uint8_t output[BUF_SIZE];
uint8_t output2[BUF_SIZE];
#pragma DATA_SECTION(input, ".ll2Data");
#pragma DATA_SECTION(output, ".ddr3Data");
#pragma DATA_SECTION(output2, ".ddr3Data");


/*********************************************************************************
 * FUNCTION PURPOSE: task to show the use of EdmaMgr.
********************************************************************************/
void EdmaMgr_test_task()
{
  int32_t  core_id = DNUM;

  System_printf("Begin EdmaMgr_test.\n\n");
  EdmaMgr_test_1D1D(core_id);
  EdmaMgr_test_2D2D_1D1Dlinked(core_id);
  EdmaMgr_test_1D1Dfast(core_id);
  EdmaMgr_test_1D1Dlinkedfast(core_id);
  EdmaMgr_test_maxChannels(core_id);
  EdmaMgr_test_maxChannels(core_id);
  EdmaMgr_test_1D1Dlinkedfast(core_id);
  EdmaMgr_test_1D1Dfast(core_id);
  EdmaMgr_test_2D2D_1D1Dlinked(core_id);
  EdmaMgr_test_1D1D(core_id);

  System_printf("\nEdmaMgr_test is completed. \n");

}


/*********************************************************************************
 * FUNCTION PURPOSE: main()
********************************************************************************/
void main()
{
   Task_Params      taskParams;
   Task_Handle      tsk;
   int32_t  core_id = DNUM;
   int32_t  ret_val;

   /* Cache configuration */
   cache_config();

#ifdef FC_TRACE
   /* Set default mask for FC modules */
   FCSettings_init();
   Diags_setMask(FCSETTINGS_MODNAME"+EX1234567");
#endif

   /* Create Tasks */
   Task_Params_init(&taskParams);
   taskParams.stackSize = 0x2000;
   tsk = Task_create((Task_FuncPtr)EdmaMgr_test_task,&taskParams,NULL);

   /* Initialize edmaMgr */
   ret_val = EdmaMgr_init(core_id, NULL);
   app_assert( (ret_val == 0), core_id, "EdmaMgr_init() failed \n");
   System_printf("EdmaMgr_init is completed \n");



   /* Start BIOS */
   BIOS_start();
}
