
./bin/remote_debug_client.out 0xbff00000 --putch $1 $2


