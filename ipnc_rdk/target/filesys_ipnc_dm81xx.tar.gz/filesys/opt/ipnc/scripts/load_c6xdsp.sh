

./bin/fw_load.out startup DSP ./firmware/ipnc_rdk_fw_c6xdsp.xe674


