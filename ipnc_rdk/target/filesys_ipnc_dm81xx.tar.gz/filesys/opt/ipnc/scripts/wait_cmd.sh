
./bin/remote_debug_client.out 0xbff00000 --waitch $1 $2


