

rmmod ./kermod/osa_kermod.ko

rm -f /dev/dev_dma
