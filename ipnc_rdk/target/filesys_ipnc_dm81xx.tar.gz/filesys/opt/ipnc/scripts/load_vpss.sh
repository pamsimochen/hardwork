

./bin/fw_load.out startup VPSS-M3 ./firmware/ipnc_rdk_fw_m3vpss.xem3

