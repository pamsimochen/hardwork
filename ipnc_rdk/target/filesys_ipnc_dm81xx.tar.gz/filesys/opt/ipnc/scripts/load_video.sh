

./bin/fw_load.out startup VIDEO-M3 ./firmware/ipnc_rdk_fw_m3video.xem3


